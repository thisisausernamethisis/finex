// File: tests/mocks/repositories.ts
import { ThemeTemplate } from '@prisma/client';

/**
 * Static in-memory data for ThemeTemplates, to simulate a database.
 * Includes both public and private templates owned by various users.
 */
const allTemplates: (ThemeTemplate & { isCurrentUserOwner: boolean })[] = [
  {
    id: '1',
    ownerId: 'user1',
    name: 'Supply Chain Analysis',
    description: 'Template for analyzing supply chain risks',
    payload: {},
    isPublic: true,
    isCurrentUserOwner: false,  // will be determined per user at runtime
    createdAt: new Date('2025-02-15'),
    updatedAt: new Date('2025-02-15'),
  },
  {
    id: '2',
    ownerId: 'user2',
    name: 'Market Expansion',
    description: 'Template for market expansion planning',
    payload: {},
    isPublic: true,
    isCurrentUserOwner: false,
    createdAt: new Date('2025-03-01'),
    updatedAt: new Date('2025-03-01'),
  },
  {
    id: '3',
    ownerId: 'user3',
    name: 'Private Strategy',
    description: 'Confidential template for internal strategy',
    payload: {},
    isPublic: false,  // private template
    isCurrentUserOwner: false,
    createdAt: new Date('2025-04-10'),
    updatedAt: new Date('2025-04-10'),
  },
];

/**
 * Mock implementation of ThemeTemplateRepository.listTemplates.
 * Supports filtering by search query `q` and the `mine` flag.
 */
export function listTemplates(opts: { 
  page: number; 
  limit: number; 
  userId: string; 
  q?: string | null; 
  mine?: boolean; 
}) {
  // Filter by ownership/visibility:
  let results = allTemplates.filter(t => {
    const isOwner = t.ownerId === opts.userId;
    if (opts.mine) {
      return isOwner;  // only include templates owned by this user
    } else {
      // if not "mine" view, include public templates and user's own templates
      return t.isPublic || isOwner;
    }
  });

  // Filter by search query (name or description contains the query, case-insensitive)
  if (opts.q) {
    const qLower = opts.q.toLowerCase();
    results = results.filter(t => 
      t.name.toLowerCase().includes(qLower) || 
      (t.description?.toLowerCase().includes(qLower))
    );
  }

  // Apply pagination (page & limit) - for simplicity, assume page starts at 1
  const startIndex = (opts.page - 1) * opts.limit;
  results = results.slice(startIndex, startIndex + opts.limit);

  // Mark isCurrentUserOwner dynamically based on the requesting user
  results = results.map(t => ({
    ...t,
    isCurrentUserOwner: t.ownerId === opts.userId
  }));

  return results;
}

// Other repository mock functions (for AssetRepository, ScenarioRepository, etc.) would go here.
// For brevity, not shown, but they should similarly use static data or vi.fn() as needed.
