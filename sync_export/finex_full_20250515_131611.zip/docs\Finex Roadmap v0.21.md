# Finex Roadmap **v0.21** — Retrieval, Quality & Feedback

*Last updated 2025‑05‑14*

This version extends v0.20 by integrating the calibration/confidence items flagged in the deep‑research report and earmarking an ANN‑tuning spike. Phase 7.1 remains in progress; Phase 7.2 now contains four tracks.

---

## 0 · Bird‑eye timeline

| Phase                        | Target ETA             | Primary goal                                 | Status |             |            |                                             |    |
| ---------------------------- | ---------------------- | -------------------------------------------- | ------ | ----------- | ---------- | ------------------------------------------- | -- |
| 6.5 CI Matrix Split          | 2025‑06‑05             | Parallel unit / E2E matrices                 | ⚪      |             |            |                                             |    |
| 6.5‑b Vitest Migration       | 2025‑05‑15             | Jest‑shim & circular‑fix merged              | 🟡     |             |            |                                             |    |
| 7.1 Retrieval & Prompting    | 2025‑06‑14             | Domain‑aware search, CoT prompts, ≤ 1 s P95  | 🟡     | & Prompting | 2025‑06‑14 | Domain‑aware search, CoT prompts, ≤ 1 s P95 | 🟡 |
| 7.2 Chunk & Quality          | 2025‑06‑28 *(stretch)* | Re‑chunk, re‑embed, calibration + confidence | ⚪      |             |            |                                             |    |
| 7.3 Drift & Tuning           | 2025‑07‑05             | Nightly α drift + alerts, cache pre‑warm     | ⚪      |             |            |                                             |    |
| 8.0 Product‑ready Retrieval  | 2025‑07‑26             | Analyst feedback loop, SLA 900 ms            | ⚪      |             |            |                                             |    |
| 9.0 Self‑serve Launch (Beta) | 2025‑08‑15             | Billing, paywall, LaunchDarkly               | ⚪      |             |            |                                             |    |

Legend — 🟢 complete · 🟡 active · ⚪ planned · 🔴 blocked

---

## 1 · Phase summaries (delta from v0.20)

### Phase 7.1 — Retrieval & Prompting (🟡)

*Status unchanged.* T‑302 (domain filter) and T‑303 (dynamic α) remain in progress; T‑305, T‑304, T‑301a are complete.

### Phase 7.2 — Chunk & Quality (⚪)

| Epic                      | Outcome                                 | Ticket     | Owner     | Status |
| ------------------------- | --------------------------------------- | ---------- | --------- | ------ |
| 7.2‑a Re‑Chunk Runner     | 256 ± 15 % token splitter (overlap 32)  | **T‑301b** | @data     | ⚪      |
| 7.2‑b Fresh Embeddings    | Re‑embed corpus with Ada‑3              | **T‑307**  | @ai‑infra | ⚪      |
| 7.2‑c Similarity Bench    | Recall/MRR regression suite             | **T‑308**  | @qa       | ⚪      |
| 7.2‑d Zero‑impact Rollout | Dual‑index shadow traffic               | **T‑309**  | @ops      | ⚪      |
| 7.2‑e Impact Calibration  | Isotonic mapping for –5…+5 scores       | **T‑308a** | @ai‑core  | 🟢     |
| 7.2‑f Confidence Scoring  | Composite confidence 0‑1, UI surfacing  | **T‑308b** | @ai‑core  | 🟢     |
| 7.2‑g ANN Tuning Spike    | IVF/HNSW parameter sweep (lists/probes) | **T‑307a** | @perf     | ⚪      |

### Phase 7.3 — Drift & Tuning (⚪)

| Epic                      | Outcome                             | Ticket     | Owner     | Status |
| ------------------------- | ----------------------------------- | ---------- | --------- | ------ |
| 7.3‑a Nightly α Drift Job | Cron RAGAS per‑domain               | **T‑310**  | @ai‑infra | ⚪      |
| 7.3‑b Alerting & Metrics  | Prom gauge + Slack alerts           | **T‑311**  | @ops      | ⚪      |
| 7.3‑c GPT Advisor v2      | GPT‑4o‑long alpha tuner             | **T‑312**  | @ai‑core  | ⚪      |
| 7.3‑d Cache Pre‑warm      | Nightly hybrid‑cache warm‑up script | **T‑311a** | @perf     | ⚪      |

Other Phase 8 and Phase 9 epics unchanged.

---

## 2 · Open ticket snapshot (≥ 7.1)

| ID     | Phase | Description                 | Blockers    | Status |
| ------ | ----- | --------------------------- | ----------- | ------ |
| T‑269  | 6.5   | CI matrix split             | —           | ⚪      |
| T‑302  | 7.1   | Domain‑aware hybrid search  | —           | 🟡     |
| T‑303  | 7.1   | Dynamic α scorer            | T‑302       | 🟡     |
| T‑301b | 7.2   | Re‑chunk corpus             | —           | ⚪      |
| T‑307  | 7.2   | Fresh embeddings            | T‑301b      | ⚪      |
| T‑307a | 7.2   | ANN index tuning spike      | —           | ⚪      |
| T‑308  | 7.2   | Similarity regression bench | T‑307       | ⚪      |
| T‑308a | 7.2   | Impact‑score calibration    | T‑308       | 🟢     |
| T‑308b | 7.2   | Confidence scoring & UI     | T‑308a      | 🟢     |
| T‑309  | 7.2   | Shadow rollout & flip       | T‑308       | ⚪      |
| T‑310  | 7.3   | Nightly α drift job         | T‑303       | ⚪      |
| T‑311  | 7.3   | Drift alerts                | T‑310       | ⚪      |
| T‑311a | 7.3   | Cache pre‑warm job          | —           | ⚪      |
| T‑312  | 7.3   | GPT advisor v2              | T‑310       | ⚪      |
| T‑313  | 8.0   | UI feedback loop            | —           | ⚪      |
| T‑314  | 8.0   | HITL triage dashboard       | T‑313       | ⚪      |
| T‑315  | 8.0   | SLA autoscale               | —           | ⚪      |
| T‑316  | 8.0   | Search audit log            | —           | ⚪      |
| T‑317  | 9.0   | Metered usage billing       | —           | ⚪      |
| T‑318  | 9.0   | Paywall gate                | T‑317       | ⚪      |
| T‑319  | 9.0   | LaunchDarkly rollout        | —           | ⚪      |
| T‑320  | 9.0   | Public beta launch          | T‑318 T‑319 | ⚪      |

---

## 3 · Next concrete actions

1. **Merge** SQL domain filter & unit tests (T‑302) → flip to 🟢.
2. **Enable** α heuristic fallback & GPT flag (T‑303) → flip when CI green.
3. **Land** CI matrix split prototype (T‑269) → shrink build time.
4. **Kick‑off** re‑chunk batch job (T‑301b) & ANN spike (T‑307a).
5. **Draft** calibration notebook & confidence formula (T‑308a T‑308b).

---

## 4 · Guard‑rails (unchanged)

* OpenAPI unchanged.
* ≤ 5‑file diff per PR.
* GPT advisor flag `DYNAMIC_ALPHA_GPT=1`.
* Perf: 1 s P95 (Phase 7) ► 900 ms (Phase 8) ► 700 ms (Phase 9).

---

## Appendix – RAG alignment

Phase 7.2/7.3 correspond to “Quality & Drift” umbrella described in *Finex RAG v0.18 Enhancement Plan*; calibration & confidence tickets (T‑308a/T‑308b) satisfy sections 4 & 5 of that plan.
