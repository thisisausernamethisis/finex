/**
 * Shared test constants
 * Extracted to avoid circular dependencies between test setup modules
 */

// Default test user ID
export const TEST_USER_ID = 'test-user-id';
