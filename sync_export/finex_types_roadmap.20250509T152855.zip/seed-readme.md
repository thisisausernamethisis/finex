# Database Seeding Guide

This document outlines the database seeding approach used in the Finex project, with special focus on deterministic seeding for testing and time zone handling.

## Seeding Modes

### Standard Development Seeding

For local development, run:

```bash
npm run db:seed
```

This will populate your database with development data using random IDs.

### Deterministic Seeding

For testing and CI environments, we use deterministic seeding to ensure consistent test behavior:

```bash
# With environment variable
SEED_UID=ci npm run db:seed

# Or using the dedicated script
npm run db:seed:ci
```

When `SEED_UID` is set to any value, the seeding process will:
1. Generate deterministic IDs using cuid2 with a fixed random seed (0.42)
2. Create consistent data with identical IDs across runs
3. Ensure database snapshots are bit-for-bit identical

## Time Zone Handling

All timestamps in the database are stored in UTC to ensure consistency across different environments and time zones. We enforce this by:

1. Setting dayjs default timezone to UTC in the seed script
2. Using English locale to standardize formatting
3. Ensuring all timestamps are created and compared in UTC time

```typescript
// From prisma/seed.ts
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import 'dayjs/locale/en';

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.tz.setDefault('UTC');
```

## Implementation Details

### Deterministic ID Generation

We use cuid2 with a fixed random seed when `SEED_UID` is set:

```typescript
import { createId } from 'cuid2';

const makeId = process.env.SEED_UID 
  ? (() => createId({random: () => 0.42})) 
  : undefined;

// Use in Prisma create() calls
await prisma.theme.create({
  data: {
    id: makeId ? makeId() : undefined,
    // other fields...
  }
});
```

### CI Integration

The CI workflow runs `npm run db:seed:ci` before executing tests to ensure a consistent database state. This eliminates test flakiness caused by random IDs and inconsistent timestamps.

## Best Practices

1. Always test your changes with both random and deterministic seeds
2. Keep the `SEED_UID` environment variable unset during development
3. When running contract tests locally, use `SEED_UID=local` for consistent results
4. CI scripts should always use deterministic seeding
