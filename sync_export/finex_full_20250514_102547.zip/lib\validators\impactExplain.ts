import { z } from 'zod';

/**
 * Schema for the impact explanation with chain-of-thought reasoning
 * 
 * This validates the structure of impact analysis results from the Matrix Worker
 * including the reasoning steps that support the final conclusion
 */
export const ImpactExplainSchema = z.object({
  impact: z.number()
    .int()
    .min(-5)
    .max(5)
    .describe('Impact score from -5 (severe negative) to +5 (strong positive)'),
  
  summary: z.string()
    .min(10)
    .max(500)
    .describe('A concise 2-3 sentence summary explaining the conclusion'),
  
  confidence: z.number()
    .min(0)
    .max(1)
    .describe('Confidence score between 0 and 1'),
  
  evidenceIds: z.string()
    .describe('Comma-separated list of the most relevant evidence IDs'),
  
  reasoning_steps: z.array(z.object({
    id: z.string().describe('Unique identifier for this reasoning step'),
    premise: z.string().describe('The factual premise or observation'),
    inference: z.string().describe('The logical inference or conclusion drawn'),
    confidence: z.number().min(0).max(1).describe('Confidence in this specific step (0-1)'),
    evidence: z.array(z.string()).describe('Evidence IDs supporting this step')
  }))
    .min(1)
    .max(10)
    .describe('Chain-of-thought reasoning steps leading to the conclusion')
});

/**
 * Public-facing schema that excludes the internal reasoning steps 
 * This is used for client-facing API responses
 */
export const PublicImpactSchema = ImpactExplainSchema.omit({ 
  reasoning_steps: true 
});

/**
 * Type definition for the full impact explanation including reasoning steps
 */
export type ImpactExplanation = z.infer<typeof ImpactExplainSchema>;

/**
 * Type definition for the public-facing impact data
 */
export type PublicImpact = z.infer<typeof PublicImpactSchema>;
