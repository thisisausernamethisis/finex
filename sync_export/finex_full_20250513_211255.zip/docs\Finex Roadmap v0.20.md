# Finex Roadmap v0.19 — Retrieval & Prompting Overhaul

*Last updated 2025‑05‑13*

This single roadmap **supersedes** all older fragments (v0.18, v0.17, etc.). It merges every micro‑revision, deep‑research audit note, and Phase‑7 design memo into one authoritative view.  citeturn6file2

---

## 0 · Bird's‑eye timeline

| Phase                     | Target ETA | Primary goal                                                      | Status      |
| ------------------------- | ---------- | ----------------------------------------------------------------- | ----------- |
| 0.0 Bootstrap             | 2024‑11    | Mono‑repo, CI skeleton, Postgres + Next 14                        | 🟢          |
| 1.0 Domain Models         | 2024‑12    | Assets · Scenarios · Templates ERD + seed                         | 🟢          |
| 2.0 Auth & API            | 2025‑01    | Clerk JWT flow · OpenAPI contract v0.8                            | 🟢          |
| 3.0 Template‑Library MVP  | 2025‑02    | CRUD, library search, RBAC                                        | 🟢          |
| 4.0 Matrix Engine         | 2025‑03    | BullMQ worker + impact scores                                     | 🟢          |
| 5.0 Hardening Wrap‑up     | 2025‑04    | Deterministic IDs, basic docs                                     | 🟢          |
| 6.1 Green CI              | 2025‑05    | Unit + contract pipelines green, ≥ 70 % cov., validation & RBAC   | 🟢 (closed) |
| 6.2 DI Refactor           | 2025‑05    | Injectable Prisma + unified mocks                                 | 🟢 (closed) |
| 6.3 API & Schema Security | 2025‑05    | RBAC hardening, OpenAPI diff gate, schema constraints, ≥ 80 % cov | 🟢 (closed) |
| 6.4 RAG Uplift            | 2025‑05    | RAGAS ≥ 0.80, analyst preview                                     | 🟢 (closed) |
| 6.5 CI Matrix Split       | 2025‑06    | Parallel unit/E2E, reduce build times                             | ⚪           |
| 7.1 Retrieval & Prompting | 2025‑06    | Domain‑aware search, CoT prompting, perf ≤ 1 s P95                | ⚪           |

---

## 1 · Phase summaries

### Phase 6.4 — **RAG Uplift** (🟢 Closed)

| Epic                      | Outcome                               | Ticket | Owner     | Status |
| ------------------------- | ------------------------------------- | ------ | --------- | ------ |
| 6.4‑a Evaluation Harness  | RAGAS metric calculation & CI step    | T‑260  | @ai‑infra | 🟢     |
| 6.4‑b Gold QA Dataset     | 50 rows of questions/answers for eval | T‑264  | @qa       | 🟢     |
| 6.4‑c Redis Cache         | Hybrid search caching for performance | T‑261  | @perf     | 🟢     |
| 6.4‑d Matrix Enhancements | Summary & confidence score in worker  | T‑262  | @ai‑core  | 🟢     |
| 6.4‑e Cache Integration   | Unit & integration tests for cache    | T‑265  | @testing  | 🟢     |
| 6.4‑f Preview Endpoint    | Lightweight matrix result API         | T‑266  | @api      | 🟢     |
| 6.4‑g Prometheus Metrics  | RAG cache observability counters      | T‑267  | @ops      | 🟢     |
| 6.4‑h Documentation       | Runbook and release notes             | T‑268  | @docs     | 🟢     |

**Exit criteria** met: RAGAS ≥ 0.80, <100 ms cache hits, full runbook.

### Phase 6.5 — **CI Matrix Split** (⚪ In progress)

| Epic                       | Outcome                               | Ticket | Owner  | Status |
| -------------------------- | ------------------------------------- | ------ | ------ | ------ |
| 6.5‑a Parallel Testing     | Run unit‑vs‑E2E matrices concurrently | T‑261  | @build | ⚪      |
| 6.5‑b Build Cache Strategy | Improve caching for faster builds     | —      | @build | ⚪      |

### Phase 7.1 — **Retrieval & Prompting Overhaul** (⚪ Planned)

| Epic                         | Outcome                                | Ticket | Owner     | Status |
| ---------------------------- | -------------------------------------- | ------ | --------- | ------ |
| 7.1‑a Roadmap Bump           | Publish this v0.19 roadmap             | T‑306  | @docs     | 🟢     |
| 7.1‑b Domain Column Addition | Add domain enum to Chunk model         | T‑301a | @data     | 🟢     |
| 7.1‑c Parallel Search        | Run BM25 & vector queries in parallel  | T‑305  | @perf     | ⚪      |
| 7.1‑d Domain‑Aware Search    | Filter/boost by domain, α configurable | T‑302  | @ai‑infra | ⚪      |
| 7.1‑e Dynamic Alpha          | Heuristic scorer + GPT‑advisor         | T‑303  | @ai‑core  | ⚪      |
| 7.1‑f CoT Function Prompt    | Chain‑of‑Thought + function calling    | T‑304  | @ai‑core  | ⚪      |
| 7.1‑g Re‑Chunk & Re‑Index    | 256 ± 15 % token chunks, re‑embed      | T‑301b | @data     | ⚪      |

**Exit criteria**:

1. Domain column live with zero‑downtime migration.
2. SearchService hybridSearch uses dynamic α.
3. RAGAS ≥ 0.85 on gold set.
4. End‑to‑end latency ≤ 1 s P95.
5. Function‑call JSON outputs validated by contract tests.

---

## 2 · Open ticket snapshot

| ID     | Phase | Description                             | Blockers     | Status |
| ------ | ----- | --------------------------------------- | ------------ | ------ |
| T‑261  | 6.5   | CI Matrix Split for parallel test runs  | —            | ⚪      |
| T‑301a | 7.1   | Add domain column to Chunk model        | —            | 🟢     |
| T‑305  | 7.1   | Run BM25 & vector queries in parallel   | —            | ⚪      |
| T‑302  | 7.1   | Domain‑aware hybrid search              | T‑301a       | ⚪      |
| T‑303  | 7.1   | Dynamic alpha with heuristic scorer     | T‑302        | ⚪      |
| T‑304  | 7.1   | CoT function prompt for worker          | —            | ⚪      |
| T‑301b | 7.1   | Re‑chunk corpus & regenerate embeddings | T‑301a T‑305 | ⚪      |

Closed tickets through v0.18 listed in appendix.

---

## 3 · Recent commits (since v0.18)

| Hash     | Date       | Title                                       |
| -------- | ---------- | ------------------------------------------- |
| g3h4i5j6 | 2025‑05‑13 | docs(roadmap): bump to v0.19 with Phase 7.1 |

---

## 4 · Next concrete actions

1. ✅ **Complete** T‑301a – zero‑downtime migration adding domain enum.
2. **Implement** T‑305 – parallel BM25/vector queries (searchService).
3. **Implement** T‑302 – domain filter & α param.
4. **Implement** T‑303 – heuristic + GPT advisor for dynamic α.
5. **Implement** T‑304 – CoT prompt + OpenAI function call.
6. **Implement** T‑301b – re‑chunk corpus & re‑embed.
7. **Finalize** Phase 6.5 CI matrix split branch.

---

## 5 · Phase 7.1 guard‑rails

* **Contract‑first**: OpenAPI remains unchanged; only internal logic evolves.
* **One‑task‑one‑PR**: ≤ 5 files/ticket, CI green per merge.
* **Data migration**: simple ALTER ADD COLUMN + backfill script.
* **Dynamic α**: heuristic first; GPT advisor behind `DYNAMIC_ALPHA_GPT` flag.
* **Prompt discipline**: hidden `reasoning_steps` key stripped pre‑persist.
* **Perf budget**: ANN index `ivfflat lists=100` on Neon; ≤ 1 s P95.

---

## Appendix – audit cross‑reference

All items flagged in *Finex Project Audit (Mid‑Phase 6)* have been addressed via Phase 6.4 uplift and scheduled Phase 7.1 tasks. See deep‑research memo alignment. citeturn6file2
