Finex Road-map v0.22 — Retrieval, Quality & Feedback
Supersedes v0.21 • Last updated 2025-05-15

This revision synchronises the road-map with the latest codebase/diagram and ground-truth:

splits the Confidence epic into backend (done) and UI banner (pending)

adds a Calibrator-retrain CLI for real isotonic fitting

inserts a Test-DB migration shim ticket to unblock CI

keeps all earlier targets / guard-rails intact

Legend — 🟢 complete · 🟡 active · ⚪ planned · 🔴 blocked

0 · Bird-eye timeline
Phase	Target ETA	Primary goal	Status
6.5 CI Matrix Split	2025-06-05	Parallel unit / E2E matrices + Vitest shim	🟡
6.5-c Test-DB Migration Shim	2025-05-20	In-memory SQLite fixture – eliminates P3018 failures	⚪
7.1 Retrieval & Prompting	2025-06-14	Domain filter, dynamic α, CoT prompts, ≤ 1 s P95	🟢
7.2 Chunk & Quality	2025-06-28*	Re-chunk & re-embed, calibration backend, confidence banner	🟡
7.3 Drift & Tuning	2025-07-05	Nightly α drift, ANN tuning, cache pre-warm, retrain CLI	⚪
8.0 Product-ready Retrieval	2025-07-26	Analyst feedback loop, SLA 900 ms	⚪
9.0 Self-serve Launch (Beta)	2025-08-15	Billing, paywall, LaunchDarkly	⚪

1 · Phase summaries
6.5 — CI & Test Infrastructure (🟡)
Epic	Outcome	Ticket	Status
6.5-a Matrix Split	Unit / E2E jobs run in parallel	T-269	🟢
6.5-b Vitest Migration	Jest-shim + circular-dep fix	T-269b	🟡
6.5-c Test-DB Migration Shim	SQLite memory DB for migration tests	T-269c	⚪

7.1 — Retrieval & Prompting Overhaul (🟢)
Epic	Outcome	Ticket	Status
Domain Column Addition	Zero-downtime enum, back-fill	T-301a	🟢
Parallel BM25 + Vector Query	Promise.all hybrid	T-305	🟢
Domain Filter in Search	domain? param	T-302	🟢
Dynamic α (heuristic + flag)	α tuned per-query	T-303	🟢
CoT Function-prompt Upgrade	Worker uses GPT function calls	T-304	🟢

7.2 — Chunk & Quality (🟡)
Epic	Outcome	Ticket	Status
7.2-a Re-Chunk Runner	256 ± 15 % tokens, 32-tok overlap	T-301b	🟡
7.2-b Fresh Embeddings	Re-embed corpus with Ada-3	T-307	⚪
7.2-c Similarity Bench	Recall / MRR regression tests	T-308	⚪
7.2-d Shadow Rollout	Dual-index + traffic flip	T-309	⚪
7.2-e Impact Calibration (backend)	Isotonic mapping JSON, worker hookup	T-308a	🟢
7.2-f Composite Confidence (backend)	LLM × variance × rank corr	T-308b	🟢
7.2-g Confidence UI Banner	React warning when confidence < 50 %	T-308d	🟡
7.2-h ANN Tuning Spike	IVF/HNSW lists / probes sweep	T-307a	🟡

7.3 — Drift & Tuning (⚪)
Epic	Outcome	Ticket	Status
7.3-a Nightly α Drift Job	Cron runs RAGAS per-domain	T-310	⚪
7.3-b Alerting & Metrics	Prom gauge + Slack alerts	T-311	⚪
7.3-c GPT Advisor v2	GPT-4o-long dynamic α	T-312	⚪
7.3-d Cache Pre-warm	Nightly hybrid-cache warm-up	T-311a	⚪
7.3-e Calibrator Retrain CLI	Script fits isotonic from gold set	T-308e	⚪

(Later phases 8.0 / 9.0 unchanged)

2 · Open-ticket snapshot
ID	Phase	Description	Blockers	Status
T-269	6.5	CI matrix split	—	🟢
T-269b	6.5	Vitest migration shim	—	🟡
T-269c	6.5	Test-DB migration fixture	—	⚪
T-302	7.1	Domain-aware hybrid search	—	🟢
T-303	7.1	Dynamic α scorer	T-302	🟢
T-301b	7.2	Re-chunk corpus & overlaps	—	🟡
T-307	7.2	Fresh embeddings (Ada-3)	T-301b	⚪
T-307a	7.2	ANN index tuning spike	—	🟡
T-308	7.2	Similarity regression bench	T-307	⚪
T-308a	7.2	Impact-score calibration backend	T-308	🟢
T-308b	7.2	Composite confidence backend	T-308a	🟢
T-308d	7.2	Confidence UI banner	T-308b	🟡
T-309	7.2	Zero-impact shadow rollout	T-308	⚪
T-310	7.3	Nightly α drift job	T-303	⚪
T-311	7.3	Drift alerts & Prom metrics	T-310	⚪
T-311a	7.3	Cache pre-warm scheduler	—	⚪
T-312	7.3	GPT-advisor v2 (LLM α)	T-310	⚪
T-308e	7.3	Calibrator retrain CLI	T-308a	⚪
T-313–T-320	8–9	Feedback loop, SLA, billing, beta	see v0.20	⚪

3 · Next concrete actions
Merge domain filter SQL + tests (finish T-302 → 🟢). ✅

Enable heuristic dynamic α and wrap GPT flag (T-303). ✅

Ship Test-DB migration shim (T-269c) so full CI passes again.

Continue re-chunk batch (T-301b) & ANN tuning spike (T-307a).

Front-end: build confidence UI banner (T-308d).

Draft isotonic-fit notebook → commit real mapping via T-308e.

4 · Guard-rails (unchanged)
OpenAPI stable – internal fields (confidence) OK.

≤ 5-file diff per PR.

DYNAMIC_ALPHA_GPT=1 gates GPT advisor.

Perf budgets: 1 s P95 (Phase 7) → 900 ms (Phase 8) → 700 ms (Phase 9).

Appendix – RAG alignment
Phase 7.2 "Chunk & Quality" fully covers sections 1-5 of Finex RAG v0.18 Enhancement Plan:
re-chunk/embedding, ANN sweep, calibration & composite confidence.
Upcoming Phase 7.3 tickets map to sections 6-7 (drift detection, pre-warm).
