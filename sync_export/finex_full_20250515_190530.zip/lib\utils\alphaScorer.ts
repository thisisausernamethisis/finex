// Re-export alphaHeuristic functionality for backward compatibility
import { pickAlpha, scoreMerge } from './alphaHeuristic';
export { pickAlpha, scoreMerge };
