# Finex RAG Retrieval Runbook

This runbook provides documentation on Finex's retrieval-augmented generation (RAG) system, including strategies for tuning parameters, troubleshooting, and performance optimization.

## Table of Contents

- [System Architecture](#system-architecture)
- [Alpha Parameter Tuning](#alpha-parameter-tuning)
- [Domain Filtering](#domain-filtering)
- [Performance Optimization](#performance-optimization)
- [ANN Indexing Strategy](#ann-indexing-strategy)
- [Troubleshooting](#troubleshooting)
- [Benchmarking](#benchmarking)

## System Architecture

Finex implements a hybrid search system combining keyword-based and vector-based retrieval:

1. **Keyword Search**: Uses PostgreSQL full-text search capabilities
2. **Vector Search**: Uses pgvector for similarity search with embeddings
3. **Hybrid Fusion**: Combines results with dynamic weighting (alpha)

The main search flow is:

```
Query → [Text Search] → Results A
     → [Vector Search] → Results B
     → [Score Merge] → Combined Results
```

## Alpha Parameter Tuning

The alpha parameter controls the balance between vector and keyword search results. It ranges from 0 (pure keyword) to 1 (pure vector).

### Dynamic Alpha Heuristics

As of v7.1, Finex implements dynamic alpha calculation based on query characteristics:

- Short, keyword-like queries (e.g., codes, IDs) favor keyword search (lower alpha)
- Long, natural language queries favor vector search (higher alpha)
- Queries with special characters, quotes or numbers favor keyword search
- Questions (starting with who, what, when, etc.) favor vector search
- Domain context influences the alpha value

### GPT-Powered Alpha Tuning

When the `DYNAMIC_ALPHA_GPT` environment variable is set to `true`, Finex will use GPT to dynamically determine the optimal alpha value by analyzing query characteristics.

To enable:
```bash
export DYNAMIC_ALPHA_GPT=true
```

For production deployments:
```yaml
# In Kubernetes config
env:
  - name: DYNAMIC_ALPHA_GPT
    value: "true"
```

## Domain Filtering

The retrieval system now supports domain filtering to limit search scope to specific domains:

Example usage:
```typescript
// Single domain
const results = await hybridSearch({
  query: "financial analysis",
  domain: ["FINANCE"]
});

// Multiple domains
const results = await hybridSearch({
  query: "regulatory impact",
  domain: ["LEGAL", "REGULATORY"]
});
```

Domain filtering works at the SQL level for both keyword and vector search components, improving both precision and performance.

## Performance Optimization

Several optimizations have been implemented:

1. **Parallel Search Execution**: Text and vector searches run concurrently
2. **Caching**: Results are cached with a 5-minute TTL, with cache keys that include domain filters
3. **Batch Processing**: Large operations are processed in batches
4. **Metrics Collection**: Latency and throughput metrics are collected for monitoring

## ANN Indexing Strategy

As part of Phase 7.2, we're implementing approximate nearest neighbor (ANN) indexing:

### Current Approach

Currently using exact nearest neighbor search which is:
- Accurate but slower
- CPU-intensive
- Scales poorly with data size

### ANN Implementation (In Progress)

We are evaluating two pgvector index types:

1. **IVF (Inverted File)**
   - Clusters vectors into lists
   - Parameters to tune:
     - `lists`: Number of clusters (typically sqrt(n) where n is row count)
     - `probes`: Number of clusters to search (higher = more accurate but slower)

2. **HNSW (Hierarchical Navigable Small World)**
   - Multi-layer graph structure for efficient search
   - Parameters to tune:
     - `m`: Maximum number of connections per node
     - `ef_construction`: Size of dynamic candidate list during construction

Use the ANN tuning script to determine optimal parameters:
```bash
psql -f scripts/ann/tune.sql
```

## Troubleshooting

Common issues and solutions:

### Slow Search Performance

1. Check query caching status (log shows cache hits/misses)
2. Verify index utilization with `EXPLAIN ANALYZE`
3. Check for very large embeddings or text fields
4. Monitor CPU and memory usage during search operations

### Poor Search Quality

1. Examine the alpha value using diagnostic endpoints
2. Review domain filtering configuration
3. Check embeddings quality and model version
4. Analyze query characteristics that might be problematic

### High Memory Usage

1. Review batch sizes for processing
2. Check for memory leaks in worker processes
3. Evaluate index efficiency and memory consumption
4. Consider scaling horizontally if needed

## Benchmarking

We use several metrics to evaluate retrieval performance:

1. **Technical Metrics**:
   - Latency (p50, p90, p95, p99)
   - Throughput (queries per second)
   - Recall@k (compared to exhaustive search)

2. **RAG Quality Metrics** (via RAGAS):
   - Answer relevance
   - Context precision 
   - Faithfulness to source documents

To run benchmarks:
```bash
# Technical performance benchmarks
npm run benchmark:search

# RAG quality benchmarks
npm run rag:eval
```

Benchmark results are stored in the metrics system and can be visualized in Grafana dashboards.

## Future Roadmap

- Implementation of full ANN indexing (IVF/HNSW) 
- Enhanced calibration tooling for quality measurement
- Support for multi-model embedding fusion
- Confidence scoring in retrieval results
