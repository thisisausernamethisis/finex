# Finex Roadmap v0.22

## Overview

This roadmap outlines our development plan for the Finex application, focusing on improving the core RAG capabilities, enhancing the UI/UX, and building key infrastructure.

## Phase 7: Production RAG Optimization (Current)

### Phase 7.1: Core Retrieval Improvements 🟢 CLOSED

| Task ID | Name | Status | Description |
|---------|------|--------|-------------|
| T-301a | Domain Column | 🟢 | Add domain classification to chunks |
| T-301b | Rechunk & Reindex | 🟢 | Optimize chunk size (~256 tokens) |
| T-302 | Domain-aware Hybrid Search | 🟢 | Filter search results by domain context |
| T-303 | Dynamic Alpha | 🟢 | Smart vector/keyword weighting based on query type |
| T-304 | CoT Function Prompting | 🟢 | Chain-of-thought reasoning in analysis flow |
| T-305 | TopK Limit & Parallel Query | 🟢 | Optimize vector search performance |

### Phase 7.2: Advanced Metrics & Visualization 🟡 IN PROGRESS

| Task ID | Name | Status | Description |
|---------|------|--------|-------------|
| T-306 | Roadmap Bump | 🟡 | Update roadmap to v0.22 |
| T-307 | YAML Dep Graph | 🟡 | Task dependency visualization |
| T-308 | RAGAS CI Gate | 🟡 | Automated quality checks for RAG |
| T-309 | Ingestion Domain Fallback | 🟡 | Ensure domain classification for all content |

### Phase 7.3: Calibration System 🟠 PLANNED

| Task ID | Name | Status | Description |
|---------|------|--------|-------------|
| T-310 | Calibration Tools | 🟠 | Build dataset generation tools |
| T-311 | Apply Calibrators | 🟠 | Implement calibration in matrix worker |
| T-312 | Schema Confidence API | 🟠 | Update OpenAPI schema with confidence fields |
| T-313 | UI Confidence Badge | 🟠 | Visual indicators for result confidence |

### Phase 7.4: Infrastructure Optimization 🟠 PLANNED

| Task ID | Name | Status | Description |
|---------|------|--------|-------------|
| T-314 | ANN IVFFlat Index | 🟠 | Enhance vector search speed with approximate nearest neighbor |
| T-315 | CI Gate Calibration | 🟠 | Automated confidence threshold verification |

## Phase 8: Enterprise Features (Next)

### Phase 8.1: Advanced Search Experience 🟠 PLANNED

| Task ID | Name | Status | Description |
|---------|------|--------|-------------|
| T-401 | Search-time Filters | 🟠 | UI for domain/date/source filtering |
| T-402 | Semantic Sort Options | 🟠 | Multiple sorting methods for results |
| T-403 | Enhanced Result Display | 🟠 | Rich formatting with highlight snippets |
| T-404 | Search History | 🟠 | Save and recall previous searches |

### Phase 8.2: Knowledge Graph 🟠 PLANNED

| Task ID | Name | Status | Description |
|---------|------|--------|-------------|
| T-411 | Entity Extraction | 🟠 | Identify key entities in content |
| T-412 | Relationship Mapping | 🟠 | Connect related entities |
| T-413 | Graph Visualization | 🟠 | Interactive knowledge graph UI |
| T-414 | Entity Linking API | 🟠 | Connect content across sources |

## Next Actions

Kick-off CI-matrix merge (T-269) & start re-chunk batch (T-301b).

## Legend

- 🟢 Closed
- 🟡 In Progress
- 🟠 Planned
- 🔴 Blocked
