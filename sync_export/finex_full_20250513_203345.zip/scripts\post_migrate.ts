import backfill from './backfill_chunk_domain';
import { logger } from '../lib/logger';

const migrationLogger = logger.child({ component: 'PostMigration' });

/**
 * Post-migration script that runs after the migration is complete
 * Called automatically by the Prisma migration engine
 */
async function postMigrate() {
  migrationLogger.info('Running post-migration domain backfill...');
  
  try {
    const results = await backfill();
    
    migrationLogger.info('Domain backfill complete with results:', {
      total: results.total,
      asset: results.asset,
      supplyChain: results.supplyChain,
      geography: results.geography,
      other: results.other,
      otherPercentage: Math.round((results.other / results.total) * 100)
    });
    
    if (results.other / results.total > 0.02) {
      migrationLogger.warn(`ATTENTION: More than 2% of chunks (${Math.round((results.other / results.total) * 100)}%) are still classified as OTHER`);
    } else {
      migrationLogger.info('Domain backfill successful with acceptable OTHER percentage');
    }
  } catch (error) {
    migrationLogger.error('Error during domain backfill:', error);
    throw error; // Re-throw to fail the migration if backfill fails
  }
}

// Execute the function
postMigrate().catch(error => {
  migrationLogger.error('Fatal error in post-migration script:', error);
  process.exit(1);
});
