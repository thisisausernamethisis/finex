// Converted to ESM syntax
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
