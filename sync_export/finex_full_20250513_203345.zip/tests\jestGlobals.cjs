/* Single export keeps hoisting semantics */
module.exports = require('./vitestJestShim.cjs');
