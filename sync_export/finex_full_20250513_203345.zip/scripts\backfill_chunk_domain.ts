import { PrismaClient } from '@prisma/client';
import { logger } from '../lib/logger';

// Define Domain enum manually to match schema.prisma
// This will be used until Prisma client is regenerated
enum Domain {
  ASSET = 'ASSET',
  SUPPLY_CHAIN = 'SUPPLY_CHAIN',
  GEOGRAPHY = 'GEOGRAPHY',
  OTHER = 'OTHER'
}

const prisma = new PrismaClient();
const backfillLogger = logger.child({ component: 'ChunkDomainBackfill' });

/**
 * Backfill domain values for existing chunks using a three-rule heuristic:
 * 1. Asset detection: Content related to companies, financial assets
 * 2. Supply Chain detection: Content with supply chain keywords
 * 3. Geography detection: Content referencing locations, regions
 * 
 * Anything not matching these will remain as OTHER
 */
async function backfillChunkDomain() {
  backfillLogger.info('Starting domain backfill for chunks');
  
  // Get total count for reporting
  const totalChunks = await prisma.chunk.count();
  
  // Process in batches to avoid memory issues
  const batchSize = 1000;
  let processedCount = 0;
  let assetCount = 0;
  let supplyChainCount = 0;
  let geographyCount = 0;
  let otherCount = 0;
  
  // Get all chunks without processing the whole result set at once
  backfillLogger.info(`Processing ${totalChunks} chunks in batches of ${batchSize}`);
  
  let hasMore = true;
  let lastId = '';
  
  while (hasMore) {
    // Fetch next batch
    const chunks = await prisma.chunk.findMany({
      where: { 
        id: { gt: lastId }
      },
      select: {
        id: true,
        content: true,
        card: {
          select: {
            title: true,
            theme: {
              select: {
                name: true,
                asset: {
                  select: {
                    name: true
                  }
                },
                scenario: {
                  select: {
                    name: true
                  }
                }
              }
            }
          }
        }
      },
      orderBy: { id: 'asc' },
      take: batchSize
    });
    
    if (chunks.length === 0) {
      hasMore = false;
      break;
    }
    
    lastId = chunks[chunks.length - 1].id;
    
    // Apply domain classification rules
    const updates = chunks.map(chunk => {
      const content = chunk.content.toLowerCase();
      const cardTitle = chunk.card?.title?.toLowerCase() || '';
      const themeName = chunk.card?.theme?.name?.toLowerCase() || '';
      const assetName = chunk.card?.theme?.asset?.name?.toLowerCase() || '';
      const scenarioName = chunk.card?.theme?.scenario?.name?.toLowerCase() || '';
      
      // Combined text to check for keywords
      const fullText = `${content} ${cardTitle} ${themeName} ${assetName} ${scenarioName}`;
      
      // Rule 1: ASSET detection
      const assetKeywords = [
        'stock', 'equity', 'shares', 'market cap', 'revenue', 'profit', 'earnings', 
        'company', 'corporation', 'investor', 'investment', 'portfolio', 'trading',
        'nasdaq', 'nyse', 'dividend', 'valuation', 'financial', 'balance sheet'
      ];
      
      // Rule 2: SUPPLY_CHAIN detection
      const supplyChainKeywords = [
        'supply chain', 'logistics', 'inventory', 'warehouse', 'shipping', 'supplier',
        'distribution', 'manufacturing', 'procurement', 'production', 'operations',
        'delivery', 'transport', 'import', 'export', 'freight', 'raw material'
      ];
      
      // Rule 3: GEOGRAPHY detection
      const geographyKeywords = [
        'country', 'region', 'city', 'continent', 'global', 'international', 'market',
        'europe', 'asia', 'america', 'africa', 'oceania', 'location', 'territory',
        'border', 'geographic', 'world', 'nation', 'province', 'state', 'local'
      ];
      
      // Determine domain based on keyword matches
      let domain = Domain.OTHER;
      
      if (assetKeywords.some(keyword => fullText.includes(keyword))) {
        domain = Domain.ASSET;
        assetCount++;
      } else if (supplyChainKeywords.some(keyword => fullText.includes(keyword))) {
        domain = Domain.SUPPLY_CHAIN;
        supplyChainCount++;
      } else if (geographyKeywords.some(keyword => fullText.includes(keyword))) {
        domain = Domain.GEOGRAPHY;
        geographyCount++;
      } else {
        otherCount++;
      }
      
      return {
        id: chunk.id,
        domain
      };
    });
    
    // Execute the updates in batch
    if (updates.length > 0) {
      await Promise.all(
        updates.map(update => 
          prisma.chunk.update({
            where: { id: update.id },
            data: { 
              // @ts-ignore - domain property will exist after migration
              domain: update.domain 
            }
          })
        )
      );
    }
    
    processedCount += chunks.length;
    backfillLogger.info(`Processed ${processedCount}/${totalChunks} chunks (${Math.round(processedCount/totalChunks*100)}%)`);
  }
  
  // Log summary
  const percentageOther = Math.round((otherCount / totalChunks) * 100);
  backfillLogger.info('Domain backfill complete. Summary:');
  backfillLogger.info(`  Total chunks processed: ${totalChunks}`);
  backfillLogger.info(`  ASSET: ${assetCount} (${Math.round(assetCount/totalChunks*100)}%)`);
  backfillLogger.info(`  SUPPLY_CHAIN: ${supplyChainCount} (${Math.round(supplyChainCount/totalChunks*100)}%)`);
  backfillLogger.info(`  GEOGRAPHY: ${geographyCount} (${Math.round(geographyCount/totalChunks*100)}%)`);
  backfillLogger.info(`  OTHER: ${otherCount} (${percentageOther}%)`);
  
  if (percentageOther > 2) {
    backfillLogger.warn(`WARNING: ${percentageOther}% of chunks still classified as OTHER, which exceeds the 2% threshold`);
  }
  
  return {
    total: totalChunks,
    asset: assetCount,
    supplyChain: supplyChainCount,
    geography: geographyCount,
    other: otherCount
  };
}

export default backfillChunkDomain;
