import OpenAI from 'openai';
import { logger } from '../logger';

const openai = new OpenAI();
const scorerLogger = logger.child({ component: 'AlphaScorer' });

/**
 * Type definition for search result hits
 */
type Hit = { id: string; score: number };

/**
 * Merges vector and keyword search results with a dynamic alpha weighting
 * 
 * @param vec Vector search results
 * @param kw Keyword (BM25) search results
 * @param options Options including domain presence
 * @returns Combined and sorted results
 */
export async function scoreMerge(
  vec: Hit[],
  kw: Hit[],
  { domain }: { domain?: string }
): Promise<Hit[]> {
  // Get the appropriate alpha value based on domain presence
  const α = await pickAlpha(Boolean(domain));
  scorerLogger.debug(`Using alpha value: ${α}, domain present: ${Boolean(domain)}`);
  
  // Map to track combined scores by ID
  const byId = new Map<string, number>();
  
  // Add vector scores with alpha weighting
  for (const hit of vec) {
    byId.set(hit.id, (byId.get(hit.id) ?? 0) + α * hit.score);
  }
  
  // Add keyword scores with inverse alpha weighting
  for (const hit of kw) {
    byId.set(hit.id, (byId.get(hit.id) ?? 0) + (1 - α) * hit.score);
  }
  
  // Convert map to array, sort by score descending
  const results: Hit[] = [];
  byId.forEach((score, id) => {
    results.push({ id, score });
  });
  
  return results.sort((a, b) => b.score - a.score);
}

/**
 * Determines the optimal alpha value based on domain presence
 * and feature flag configuration
 * 
 * @param hasDomain Whether a domain filter is present
 * @returns The alpha value between 0 and 1
 */
async function pickAlpha(hasDomain: boolean): Promise<number> {
  // Use heuristic values if GPT feature flag isn't enabled
  if (process.env.FINEX_ALPHA_MODE !== 'gpt') {
    return hasDomain ? 0.65 : 0.5;
  }
  
  try {
    // Use GPT to determine alpha dynamically
    const { choices } = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      max_tokens: 4,
      messages: [
        { role: 'system', content: 'Return a single number 0-1 for α weighting.' },
        { role: 'user', content: hasDomain ? 'domain present' : 'no domain' },
      ],
    });
    
    // Parse the response and ensure it's a valid number between 0 and 1
    const n = parseFloat(choices[0].message.content ?? '');
    if (Number.isFinite(n)) {
      return Math.max(0, Math.min(1, n));
    }
    
    // Fallback if parsing fails
    scorerLogger.warn(`Failed to parse GPT alpha response: ${choices[0].message.content}`);
    return 0.6;
  } catch (error) {
    // Log error and use fallback alpha if GPT call fails
    scorerLogger.error('Error calling GPT for alpha determination:', error);
    return hasDomain ? 0.65 : 0.5;
  }
}
