# RAG System Runbook

## Overview

This document describes the Retrieval-Augmented Generation (RAG) system used in Finex v0.18, including its components, maintenance procedures, and troubleshooting steps.

## Architecture

The RAG system consists of the following components:

1. **Hybrid Search Service** - Combines semantic search and keyword search for improved results
2. **Redis Cache** - Caches search results to improve performance and reduce API costs
3. **Matrix Worker** - Generates summaries with confidence scores based on retrieved content
4. **RAGAS Evaluation** - Measures RAG system quality and maintains performance standards
5. **Preview API** - Endpoint for retrieving lightweight matrix result previews

## Components

### Search Service

The search service uses a hybrid approach:
- Semantic search: Uses embeddings to find contextually similar content
- Keyword search: Traditional text matching for precise terms
- Results are combined and ranked to provide comprehensive answers

The service is implemented in `lib/services/searchService.ts`.

### Redis Cache

To improve performance and reduce costs:
- Search queries and results are cached in Redis
- Cache keys are generated using a hash of the query and any metadata
- Default TTL is 300 seconds (5 minutes)
- Performance metrics are collected for monitoring

The cache is implemented in `lib/services/cacheService.ts`.

### Matrix Worker

The matrix worker:
- Processes asset and scenario data
- Uses the search service to find relevant information
- Generates summaries with confidence scores
- Stores results in the database

The worker code is in `workers/matrixWorker.ts`.

### RAGAS Evaluation

The RAGAS (Retrieval Augmented Generation Assessment) framework:
- Measures the quality of RAG results
- Uses gold standard question-answer pairs from `tests/rag/qa.csv`
- Evaluates key metrics: faithfulness, relevance, and contextual precision
- Enforces a minimum overall score of 0.80 in CI

The evaluation script is in `scripts/rag/eval.ts`.

### Preview API

The matrix result preview API:
- Returns lightweight matrix analysis results
- Includes generated summary and confidence scores
- Protects data with appropriate access controls

The endpoint is defined in `app/api/matrix/result/[resultId]/preview/route.ts`.

## Monitoring

The system exposes the following Prometheus metrics:

- `finex_rag_cache_hits_total` - Counter for cache hits
- `finex_rag_cache_misses_total` - Counter for cache misses
- `finex_rag_cache_latency` - Gauge for cache operation latency in seconds

These metrics can be accessed through the `/metrics` endpoint and should be monitored for performance and health.

## Maintenance Tasks

### Refreshing the QA Dataset

The gold standard QA dataset should be periodically reviewed and updated:

1. Update the CSV file at `tests/rag/qa.csv`
2. Run the evaluation script: `npm run rag:eval`
3. Ensure the overall RAGAS score remains above 0.80

### Cache Management

To flush the entire RAG cache:

```bash
redis-cli -h <REDIS_HOST> -p <REDIS_PORT> KEYS "hs:*" | xargs redis-cli DEL
```

To adjust cache TTL for specific query types, modify the `ttlSec` parameter in `cacheService.ts`.

## Troubleshooting

### Low RAGAS Scores

If the RAGAS evaluation score drops below threshold:

1. Check the QA dataset for quality and coverage
2. Review search service parameters (weights, top_k)
3. Check if the confidence scores align with actual result quality
4. Consider retraining embeddings if semantic search quality has degraded

### Cache Issues

If experiencing cache-related problems:

1. Check Redis connectivity and configuration
2. Verify cache key generation for correctness
3. Monitor cache hit/miss ratios through metrics
4. Ensure the TTL settings are appropriate for your use case

### Summary Quality Issues

For problems with summary quality:

1. Review the input data quality
2. Check the confidence scores (lower scores indicate potential issues)
3. Verify that the matrix worker has access to all necessary context
4. Consider increasing the context window or refining the search parameters

## Technical Notes

- The confidence calculation uses the LLM's reported confidence and is normalized to a 0-1 scale
- Redis cache keys use SHA-1 hashing of query + metadata to ensure uniqueness
- The hybrid search combines results using a weighted approach (60% semantic, 40% keyword by default)
- RAGAS evaluation runs both at development time and in CI to prevent regressions
