# Finex Roadmap v0.21 — Beyond Phase 7.1

*Last updated 2025‑05‑14*

This edition rolls the roadmap forward through **Phase 8** (Product‑ready Retrieval) and **Phase 9** (Self‑serve Launch). It is derived from the latest ground‑truth specification citeground-truth.md and the approved RAG enhancement plan citeFinex RAG v0.18 Enhancement Plan and Roadmap Alignment.pdf.

> **Highlight** — Phase 7.1 is now 60 % complete; next milestones focus on chunk quality, Alpha tuning stabilisation, and CI hardening.

---

## 0 · Bird‑eye timeline

| Phase                             | Target ETA     | Primary goal                                              | Status |
| --------------------------------- | -------------- | --------------------------------------------------------- | ------ |
| 6.5 CI Matrix Split               | 2025‑06‑05     | Parallel unit/E2E, build cache                            | ⚪      |
| **7.1 Retrieval & Prompting**     | **2025‑06‑14** | Domain‑aware search, CoT prompts, ≤ 1 s P95               | 🟡     |
| **7.2 Chunk & Embedding Quality** | 2025‑06‑28     | Re‑chunking, re‑embed corpus, similarity regression bench | ⚪      |
| **7.3 Dynamic Search Tuning**     | 2025‑07‑05     | Auto‑α drift monitor, nightly RAG drift alerts            | ⚪      |
| **8.0 Product‑ready Retrieval**   | 2025‑07‑26     | Live analyst feedback loop, audit log, SLA 95 % P90       | ⚪      |
| **9.0 Self‑serve Launch (Beta)**  | 2025‑08‑15     | Paywall, metering, LaunchDarkly toggles                   | ⚪      |

Legend — 🟢 complete · 🟡 in progress · ⚪ planned · 🔴 blocked

---

## 1 · Phase summaries (new work only)

### Phase 7.2 — Chunk & Embedding Quality (⚪ planned)

| Epic                      | Outcome                                       | Ticket | Owner     | Status |
| ------------------------- | --------------------------------------------- | ------ | --------- | ------ |
| 7.2‑a Re‑Chunk Runner     | 256 ± 15 % token splitter (overlap 32)        | T‑301b | @data     | ⚪      |
| 7.2‑b Fresh Embeddings    | Re‑embed via OpenAI Ada‑3, store in pgvector  | T‑307  | @ai‑infra | ⚪      |
| 7.2‑c Similarity Bench    | Regression suite (MRR, Recall\@k on gold set) | T‑308  | @qa       | ⚪      |
| 7.2‑d Zero‑impact Rollout | Dual‑index shadow reads, flip when P95 stable | T‑309  | @ops      | ⚪      |

**Exit criteria 7.2** — new chunks boost RAGAS +0.03; no latency regression.

---

### Phase 7.3 — Dynamic Search Tuning (⚪ planned)

| Epic                      | Outcome                                | Ticket | Owner     | Status |
| ------------------------- | -------------------------------------- | ------ | --------- | ------ |
| 7.3‑a Nightly α Drift Job | Cron evaluates RAGAS per‑domain        | T‑310  | @ai‑infra | ⚪      |
| 7.3‑b Alerting & Metrics  | Prometheus gauge & Slack alert         | T‑311  | @ops      | ⚪      |
| 7.3‑c GPT Advisor v2      | Switch to GPT‑4o‑long w/ system rubric | T‑312  | @ai‑core  | ⚪      |

### Phase 8.0 — Product‑ready Retrieval (⚪ planned)

| Epic                         | Outcome                                         | Ticket | Owner | Status |
| ---------------------------- | ----------------------------------------------- | ------ | ----- | ------ |
| 8.0‑a Analyst Feedback Loop  | UI rate‑this‑answer, writes to Feedback table   | T‑313  | @ux   | ⚪      |
| 8.0‑b Human‑in‑the‑Loop Eval | Active‑learning triage dashboard                | T‑314  | @qa   | ⚪      |
| 8.0‑c SLA Enforcement        | p95 ≤ 900 ms prod; horizontal shard & autoscale | T‑315  | @ops  | ⚪      |
| 8.0‑d Audit Log              | Complete search request/response JSON persisted | T‑316  | @sec  | ⚪      |

### Phase 9.0 — Self‑serve Launch (Beta) (⚪ planned)

| Epic                | Outcome                                     | Ticket | Owner   | Status |
| ------------------- | ------------------------------------------- | ------ | ------- | ------ |
| 9.0‑a Metered Usage | Stripe billing + seat tracking              | T‑317  | @growth | ⚪      |
| 9.0‑b Paywall Gate  | Pay‑as‑you‑go endpoint auth                 | T‑318  | @growth | ⚪      |
| 9.0‑c Feature Flags | LaunchDarkly remote toggle for Retrieval V2 | T‑319  | @ops    | ⚪      |
| 9.0‑d Beta Launch   | Public sign‑up, onboarding flow             | T‑320  | @pm     | ⚪      |

---

## 2 · Open ticket snapshot (≥ Phase 7.1)

| ID     | Phase | Description                 | Blockers    | Status |
| ------ | ----- | --------------------------- | ----------- | ------ |
| T‑269  | 6.5   | CI matrix split             | —           | ⚪      |
| T‑302  | 7.1   | Domain-aware hybrid search  | none        | 🟡     |
| T‑303  | 7.1   | Dynamic alpha scorer        | T‑302       | 🟡     |
| T‑301b | 7.2   | Re‑chunk & re-embed         | T‑307       | ⚪      |
| T‑307  | 7.2   | Fresh embeddings (Ada‑3)    | —           | ⚪      |
| T‑308  | 7.2   | Similarity regression bench | T‑301b      | ⚪      |
| T‑309  | 7.2   | Zero-impact rollout         | T‑308       | ⚪      |
| T‑310  | 7.3   | Nightly α drift job         | T‑303       | ⚪      |
| T‑311  | 7.3   | RAG drift alerts            | T‑310       | ⚪      |
| T‑312  | 7.3   | GPT advisor v2              | T‑310       | ⚪      |
| T‑313  | 8.0   | UI feedback loop            | —           | ⚪      |
| T‑314  | 8.0   | HITL triage dashboard       | T‑313       | ⚪      |
| T‑315  | 8.0   | SLA enforcement autoscale   | —           | ⚪      |
| T‑316  | 8.0   | Search audit log            | —           | ⚪      |
| T‑317  | 9.0   | Metered usage billing       | —           | ⚪      |
| T‑318  | 9.0   | Paywall gate                | T‑317       | ⚪      |
| T‑319  | 9.0   | LaunchDarkly rollout        | —           | ⚪      |
| T‑320  | 9.0   | Public beta launch          | T‑318 T‑319 | ⚪      |

---

## 3 · Next concrete actions (rolling)

1. **Merge** domain‑aware SQL + unit tests (T‑302).
2. **Enable** heuristic α fallback + GPT flag (T‑303).
3. **Wire up** CI matrix split draft PR (T‑269) and measure baseline.
4. **Kick‑off** re‑chunk batch (T‑301b) – low‑priority parallel job.

---

## 4 · Long‑term guard‑rails

* OpenAPI first, breaking changes behind v2 path.
* Each Phase increment bumps RAGAS target by +0.03.
* P95 latency SLA: 1 s (Phase 7), 900 ms (Phase 8), 700 ms (Phase 9).
* FinOps cap: \$1 / 1 K requests target by Phase 8.
* Security review & SOC‑2 prep start at Phase 9.

---

## Appendix — cross‑reference docs

*Ground‑truth spec*, *RAG enhancement plan*, and *audit memo* references remain unchanged.
