# Finex Bot — Master Roadmap **v0.11 “Audit follow-up & Guard-rails”**

*Last compiled **2025-05-11** — merges v0.9 detail, v0.10 addendum, and Phase-6 audit quick-wins.*

---

## 0 · Context & Sources

* v0.9 granular track-map & check-lists :contentReference[oaicite:0]{index=0}:contentReference[oaicite:1]{index=1}  
* Full-audit executive summary & detailed findings :contentReference[oaicite:2]{index=2}:contentReference[oaicite:3]{index=3}  

---

## 1 · Phase Timeline & KPIs

| Phase | Window / ETA | Key Deliverables | KPIs / Gates |
|-------|--------------|------------------|--------------|
| **5 b – Hardening wrap-up** | **DONE** | Deterministic seed tag `v0.5.0-hardening` | CI 🟢 |
| **6 .0 – Seed polish & helper docs** | +3 d | Idempotent UPSERT seed, helper-cleanup guide | Merge T-175b → line-cov ≥68 % |
| **6 .1 – Type-safety (prod)** | **DONE** | 72 % typed, 6 nocheck banners removed | `npm run verify` 0 |
| **6 .1 a – Audit quick-wins** | **1 wk** | Unified rate-limit stub, default Clerk user mock, matrixWorker test re-enabled, nightly OpenAPI↔Zod diff | Coverage ≥75 %, CI guard-rails green |
| **6 .2 – DI & Alias unification** | 2 wks | 0 direct infra imports, `context.ts`, Jest single alias, coverage ≥80 %, Playwright smoke flow | All routes use injected `Services` |
| **6 .3 – Cost & DX guard-rails** | 2 wks | Prompt-cost sentinel, type-coverage gate, ESLint ban on `@ts-nocheck`, quota toast | `verify` fails <80 % typed |
| **6 .4 – RAG quality surfacing** | 1 wk | Inline-cache hybrid search, RAGAS ≥0.80, matrix card summary | golden-set recall ≥0.90 |
| **7 – Observability & Perf** | 3 wks | OTEL tracing, Prom+Grafana, DLQ drain CLI, nightly schema-drift job | p95 API <400 ms |
| **8 – Multi-tenant & Billing** | 2 wks | Tenant FK migration, Clerk org sync, Stripe billing | Usage ledger 100 % |
| **9 – Insight Feed α** | 2 wks | ΔRisk/ΔGrowth detector, `/insights` SSE, Insight UI | RAGAS ≥0.85 |

---

## 2 · Ticket Board (live)

| ID | Title | Phase | Owner | Status |
|----|-------|-------|-------|--------|
| **T-175a** | Deterministic seed via `SEED_UID` | 5 b | Alex P | **Merged** |
| **T-175b** | Idempotent seed cmd | 6 .0 | Alex P | *Next* |
| **T-176** | Remove `@ts-nocheck` Batch-1 (prod) | 6 .1 | Alex P | **Done** |
| **T-176c** | **Unify rate-limit logic** | 6 .1 a | Alex P | *PR open* |
| **T-176d** | **Default Clerk user mock** | 6 .1 a | Alex P | *Planned* |
| **T-177b** | **Re-enable matrixWorker test** | 6 .1 a | Rahul T | *Planned* |
| **T-177c** | **Nightly OpenAPI↔Zod diff gate** | 6 .1 a | Daniel | *Planned* |
| **T-177 / a** | Remove nocheck Batch-2 (tests) & Playwright smoke | 6 .2 | Michelle L | Planned |
| **T-180** | DI context provider skeleton | 6 .2 | Michelle L | Split |
| **T-181a** | Dev-worker bootstrap | 6 .3 | Michelle L | Planned |
| **T-182a** | **Type-coverage ≥80 % gate** | 6 .3 | Dev-Ex WG | Planned |
| **T-183** | Cost sentinel & quota toast | 6 .4 | Rahul T | Planned |
| *(full list continues in `roadmap_v0.9_detail.md`)* |

### Dependency Flow
T-175a → T-175b → {T-176c,T-176d} → T-176 ✔
│
├─ T-177b
├─ T-177c
└─ T-177 → T-177a
│
▼
T-180 … (rest)

markdown
Copy
Edit

---

## 3 · Acceptance Gates (per sub-phase)

**6 .1 a Quick-wins**  
* `npm run verify` exits 0 locally + CI  
* Coverage ≥ 75 % (prod)  
* Clerk default user mock available (`TEST_USER_ID`)  
* matrixWorker test un-skipped & stable  
* OpenAPI↔Zod nightly diff passes

**6 .2 DI / Alias**  
* 100 % API routes consume injected `Services`  
* Jest only uses mapper derived from `tsconfig.paths`  
* Line-typed ≥ 80 %, no `@ts-nocheck` banners  
* Playwright smoke (login → create asset → search) green

*(full gate list preserved from v0.9)*

---

## 4 · Risks & Mitigation

| ID | Risk | Likelihood | Impact | Mitigation |
|----|------|-----------|--------|------------|
| R-1 | VSCode alias drift | Medium | DX pain | Workspace settings mirroring Jest mapper |
| R-2 | Verify hook friction | Medium | Commit friction | `SKIP_VERIFY=1` escape; CI enforces |
| **R-3** | Spec↔code drift | Low | 400-bugs | Nightly diff gate (**T-177c**) |
| R-4 | DI cold-start on Edge | Low | p95 latency | Memoise `defaultServices` |

---

## 5 · Audit Findings → Ticket Map

| Audit Finding (priority) | Ticket / Phase | Patch Status |
|--------------------------|----------------|--------------|
| Rate-limit stub mismatch | **T-176c (6 .1 a)** | PR open |
| No default Clerk user    | **T-176d (6 .1 a)** | Planned |
| matrixWorker test flaky  | **T-177b (6 .1 a)** | Planned |
| Prisma deep-mock nocheck | **T-177 (6 .2)**    | Planned |
| Remaining nocheck banners| **T-177 / 182a**    | Planned |
| Type coverage gate       | **T-182a (6 .3)**   | Planned |
| OpenAPI↔Zod drift guard  | **T-177c (6 .1 a)** | Planned |

Executive summary citation :contentReference[oaicite:4]{index=4}:contentReference[oaicite:5]{index=5}

---

## 6 · CI Guard-rails (new / pending)

* **verify**: eslint → `tsc --noEmit` → jest/vitest → c8 → `esm:check`
* Type-coverage threshold ≥ 80 % (T-182a)
* Nightly OpenAPI↔Zod diff (T-177c)
* ESLint rule ban `@ts-nocheck`
* Grep-gate forbidding new path-based mocks after DI

---

## 7 · Immediate “Day 0” TODO (for next dev-agent)

1. **Finish PR T-176c** (`phase6.1a/T-176c_rate-limit-unify`)  
   * Re-run `npx vitest`; ensure stub + middleware share interface  
2. **Open PR T-176d**  
   * Add default Clerk user mock (`tests/setup/clerk-mock.ts`)  
3. **Un-skip & stabilise matrixWorker test** (`T-177b`)  
   * Provide typed BullMQ job payload + in-memory Redis  
4. **Draft nightly OpenAPI↔Zod diff GH Action** (`T-177c`)  
5. **Kick off DI spike branch** `phase6.2/T-180_di_context`  
   * Scaffold `context.ts`, move one sample route

> **Ping reviewers (Daniel for CI-bot) once steps 1-3 are green.**

---

*End of v0.11 roadmap*  