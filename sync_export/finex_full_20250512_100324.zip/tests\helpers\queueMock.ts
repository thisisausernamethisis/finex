import { vi } from 'vitest';

/* ─────────────────────
   Minimal queue helper
   ───────────────────── */
export class QueueMock {
  private _lastJobData: unknown;

  add = vi.fn(async (_name: string, data: unknown) => {
    this._lastJobData = data;
  });

  _getLastJobData() {
    return this._lastJobData;
  }
}

/** tiny helper used by most unit tests */
export const makeQueueMock = () => new QueueMock();

/* ─────────────────────────────────────────────
   Detailed implementation (kept for specs that
   need full inspection).  Split to avoid
   duplicate-export errors flagged by TS.
   ───────────────────────────────────────────── */
export { makeDetailedQueueMock } from './queueMock.detailed';  // << move old long impl here
