/**
 * BullMQ mock for Vitest tests
 * 
 * This provides a mock implementation of BullMQ components
 * for running tests without needing a real Redis connection.
 */

import { vi } from 'vitest';

/**
 * Mock class for BullMQ Queue
 */
export class FakeQueue { 
  name: string;
  
  constructor(name: string, options?: any) {
    this.name = name;
  }
  
  add = vi.fn().mockImplementation(() => Promise.resolve({ id: 'mock-job-id' }));
  getJob = vi.fn().mockImplementation(() => Promise.resolve(null));
  getJobs = vi.fn().mockImplementation(() => Promise.resolve([]));
  getJobCounts = vi.fn().mockImplementation(() => 
    Promise.resolve({ waiting: 0, active: 0, completed: 0, failed: 0, delayed: 0, paused: 0 })
  );
  removeJobs = vi.fn().mockImplementation(() => Promise.resolve());
  pause = vi.fn().mockImplementation(() => Promise.resolve());
  resume = vi.fn().mockImplementation(() => Promise.resolve());
  close = vi.fn().mockImplementation(() => Promise.resolve());
  on = vi.fn();
  off = vi.fn();
  once = vi.fn();
}

/**
 * Mock class for BullMQ QueueEvents
 * 
 * Implements setMaxListeners and on methods to prevent errors
 */
export class FakeQueueEvents {
  name: string;
  
  constructor(name: string, options?: any) {
    this.name = name;
  }
  
  setMaxListeners = vi.fn().mockReturnThis();
  on = vi.fn().mockReturnThis();
  once = vi.fn().mockReturnThis();
  off = vi.fn().mockReturnThis();
}

/**
 * Mock class for BullMQ Worker
 */
export class FakeWorker {
  name: string;
  
  constructor(name: string, processorFn?: any, options?: any) {
    this.name = name;
  }
  
  on = vi.fn().mockReturnThis();
  off = vi.fn().mockReturnThis();
  process = vi.fn().mockImplementation(() => Promise.resolve());
  close = vi.fn().mockImplementation(() => Promise.resolve());
}

// Export for direct usage in tests
export const Queue = FakeQueue;
export const QueueEvents = FakeQueueEvents;
export const Worker = FakeWorker;

// Mock the entire bullmq module to return our fake classes
vi.mock('bullmq', () => {
  return { 
    Queue: FakeQueue, 
    QueueEvents: FakeQueueEvents, 
    Worker: FakeWorker 
  };
});
