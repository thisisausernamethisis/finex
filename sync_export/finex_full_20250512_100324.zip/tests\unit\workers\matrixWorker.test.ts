import { describe, it, expect, vi, beforeEach, afterEach, type MockInstance } from 'vitest';
import { Worker, Queue, QueueEvents, Job } from 'bullmq';
import { startMatrixWorker, processMatrixJob } from '../../../workers/matrixWorker';
import { assembleMatrixContext } from '../../../lib/services/contextAssemblyService';
import { prisma } from '../../../lib/db';

// Mock the database access (Prisma) for matrixAnalysisResult
const prismaUpdateSpy = vi.fn();
const prismaFindUniqueSpy = vi.fn();
// Replace the real prisma import with a fake that has the needed methods
vi.mock('../../../lib/db', () => ({
  prisma: {
    matrixAnalysisResult: {
      findUnique: prismaFindUniqueSpy,
      update: prismaUpdateSpy,
    }
  }
}));

// Mock the context assembly service
const assembleContextSpy = vi.fn();
vi.mock('../../../lib/services/contextAssemblyService', () => ({
  assembleMatrixContext: assembleContextSpy
}));

// Import our proper BullMQ mock classes
import { FakeQueue, FakeQueueEvents, FakeWorker } from '../../setup/queueMock';

// Mock BullMQ components to prevent real queue operations
vi.mock('bullmq', () => ({
  Worker: FakeWorker,
  Queue: FakeQueue,
  QueueEvents: FakeQueueEvents
}));

// Global fetch mock for any OpenAI API calls inside processMatrixJob
global.fetch = vi.fn();

// Define a type for the job data to ensure type-safe access in tests
interface MatrixJobData {
  assetId: string;
  scenarioId: string;
}
// Create a reusable mock job object
const createMockJob = (assetId: string, scenarioId: string): Job<MatrixJobData> => {
  return {
    id: 'job-' + assetId + '-' + scenarioId,
    data: { assetId, scenarioId }
    // other Job properties (like progress, attemptsMade, etc) can be omitted for this test
  } as Job<MatrixJobData>;
};

describe('Matrix Worker', () => {
  const mockMatrixResult = {
    id: 'result1',
    assetId: 'asset1',
    scenarioId: 'scenario1',
    status: 'pending',
    impact: 0,
    evidenceIds: ''
  };

  beforeEach(() => {
    vi.resetAllMocks();
    // By default, pretend the DB has an existing result for asset1/scenario1 and none for others
    prismaFindUniqueSpy.mockResolvedValue(mockMatrixResult);
    prismaUpdateSpy.mockResolvedValue({ ...mockMatrixResult, status: 'processing' });
    assembleContextSpy.mockResolvedValue({ /* some mock context data */ });
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  it('processMatrixJob updates DB status and calls context assembly', async () => {
    const job = createMockJob('asset1', 'scenario1');
    await processMatrixJob(job);
    // Should fetch the existing matrixAnalysisResult once
    expect(prisma.matrixAnalysisResult.findUnique).toHaveBeenCalledWith({
      where: { assetId_scenarioId: { assetId: 'asset1', scenarioId: 'scenario1' } }
    });
    // Should update the status to 'processing'
    expect(prisma.matrixAnalysisResult.update).toHaveBeenCalledWith({
      where: { assetId_scenarioId: { assetId: 'asset1', scenarioId: 'scenario1' } },
      data: expect.objectContaining({ status: 'processing' })
    });
    // Should assemble context for the job
    expect(assembleMatrixContext).toHaveBeenCalledWith('asset1', 'scenario1');
  });

  it('processMatrixJob handles non-existent matrix result gracefully', async () => {
    // If findUnique returns null (no existing result for given asset-scenario), simulate that
    prismaFindUniqueSpy.mockResolvedValueOnce(null);
    const job = createMockJob('assetX', 'scenarioY');
    await processMatrixJob(job);
    // It should still attempt an update (perhaps creating a new record or just skipping)
    expect(prisma.matrixAnalysisResult.update).toHaveBeenCalledWith({
      where: { assetId_scenarioId: { assetId: 'assetX', scenarioId: 'scenarioY' } },
      data: expect.objectContaining({ status: 'processing' })
    });
    // Context assembly should be called with the provided IDs regardless
    expect(assembleMatrixContext).toHaveBeenCalledWith('assetX', 'scenarioY');
  });

  it('startMatrixWorker sets up BullMQ worker and queue correctly', async () => {
    // Call the function that initializes the worker
    const workerInfo = await startMatrixWorker();
    // startMatrixWorker likely returns the Worker instance or some info; ensure Worker was constructed
    expect(Worker).toHaveBeenCalled();
    expect(Queue).toHaveBeenCalled();
    expect(QueueEvents).toHaveBeenCalled();
    // Also ensure the queue events listener was configured (setMaxListeners called)
    const QueueEventsMockInstance = 
      // cast so TS knows it's the mocked version, not the real class
      (QueueEvents as unknown as MockInstance).mock.results[0].value;
    expect(QueueEventsMockInstance.setMaxListeners).toHaveBeenCalled();
    // If startMatrixWorker returns a worker instance or similar, we could verify it has process function set, etc.
    // (Not doing deep check here since Worker is fully mocked)
  });
});
