// tests/helpers/queueMock.detailed.ts
export * from './queueMock';          // keep the old import path alive
