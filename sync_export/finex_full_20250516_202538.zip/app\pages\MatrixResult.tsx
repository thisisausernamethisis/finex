'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import ConfidenceBadge from '../../src/components/ConfidenceBadge';

interface SearchResult {
  id: string;
  content: string;
  score: number;
  confidence?: number; // Now optional to handle cases where backend hasn't added it yet
}

export default function MatrixResult() {
  const searchParams = useSearchParams();
  const query = searchParams.get('query') || '';
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Don't fetch if there's no query
    if (!query) {
      setLoading(false);
      return;
    }

    const fetchSearchResults = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/search?query=${encodeURIComponent(query)}`);
        
        if (!response.ok) {
          throw new Error(`Search request failed with status: ${response.status}`);
        }
        
        const data = await response.json();
        setResults(data.results || []);
        setError(null);
      } catch (err) {
        console.error('Error fetching search results:', err);
        setError('Failed to load search results. Please try again.');
        setResults([]);
      } finally {
        setLoading(false);
      }
    };

    fetchSearchResults();
  }, [query]);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Search Results for: {query}</h1>
      
      {loading && (
        <div className="flex justify-center my-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      )}
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
          <span className="block sm:inline">{error}</span>
        </div>
      )}
      
      {!loading && !error && results.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <p>No results found for "{query}"</p>
        </div>
      )}
      
      <div className="space-y-4">
        {results.map(result => (
          <div 
            key={result.id}
            className="bg-white p-4 rounded-lg shadow border border-gray-200"
          >
            <div className="flex justify-between items-start mb-2">
              <div className="text-sm text-gray-500">Score: {(result.score * 100).toFixed(0)}%</div>
              {result.confidence !== undefined && (
                <ConfidenceBadge score={result.confidence} />
              )}
            </div>
            <p className="text-base">{result.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
