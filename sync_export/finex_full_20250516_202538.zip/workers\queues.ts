import { Queue } from 'bullmq';

// Redis connection options for BullMQ
const redisConnection = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379')
};

// Create queue for matrix analysis jobs
export const matrixQueue = new Queue('matrix-analysis', {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 5000
    },
    removeOnComplete: true,
    removeOnFail: 100
  }
});

// Create queue for probability analysis jobs
export const probabilityQueue = new Queue('probability-analysis', {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 5000
    },
    removeOnComplete: true,
    removeOnFail: 100
  }
});

// Create queue for growth analysis jobs
export const growthQueue = new Queue('growth-analysis', {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 5000
    },
    removeOnComplete: true,
    removeOnFail: 100
  }
});

// Create queue for reindexing chunks
export const reindexQueue = new Queue('reindex-chunks', {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 5000
    },
    removeOnComplete: true,
    removeOnFail: 100
  }
});

// Create queue for rechunking
export const rechunkQueue = new Queue('rechunk', {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 5000
    },
    removeOnComplete: true,
    removeOnFail: 100
  }
});

// Queue name constants for access across files
export const QUEUES = {
  matrix: 'matrix-analysis',
  probability: 'probability-analysis',
  growth: 'growth-analysis',
  reindex: 'reindex-chunks',
  rechunk: 'rechunk'
};
