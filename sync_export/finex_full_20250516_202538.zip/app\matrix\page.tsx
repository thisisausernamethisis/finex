import MatrixResult from '../pages/MatrixResult';

export default function MatrixPage() {
  return <MatrixResult />;
}
