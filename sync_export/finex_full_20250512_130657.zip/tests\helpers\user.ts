/**
 * User authentication helpers for testing
 * 
 * Provides consistent, deterministic authentication behavior for tests
 * with default admin user and configurable test users.
 */

import { vi } from 'vitest';

/**
 * Standard test user types/roles
 */
export enum TestUserType {
  ADMIN = 'admin',
  NORMAL = 'normal',
  VIEWER = 'viewer'
}

/**
 * Role enum for backward compatibility with existing tests
 */
export enum UserRole {
  ADMIN = 'ADMIN',
  EDITOR = 'EDITOR',
  VIEWER = 'VIEWER',
  DEFAULT = 'DEFAULT'
}

/**
 * Test user configuration
 */
export interface TestUser {
  id: string;
  email: string;
  name: string;
  role: TestUserType;
}

/**
 * Default admin user that is always available
 */
export const DEFAULT_ADMIN_USER: TestUser = {
  id: 'user_2QUFDx7HBlX79lXm4QVtxcX3NMN',
  email: 'admin@example.com',
  name: 'Admin User',
  role: TestUserType.ADMIN
};

/**
 * Default normal user with standard permissions
 */
export const DEFAULT_USER: TestUser = {
  id: 'user_2PQG4z9TRfH72dF98SJnCvP0Jj4',
  email: 'user@example.com',
  name: 'Normal User',
  role: TestUserType.NORMAL
};

/**
 * Default viewer with limited permissions
 */
export const DEFAULT_VIEWER: TestUser = {
  id: 'user_2XNT1v3QHfJ83kD59SJnCvP0Lm6',
  email: 'viewer@example.com',
  name: 'Viewer User',
  role: TestUserType.VIEWER
};

/**
 * Default editor user with editing permissions
 */
export const DEFAULT_EDITOR: TestUser = {
  id: 'user_2LMN5y8SJgH94kD71RJnFvZ2Kw7',
  email: 'editor@example.com',
  name: 'Editor User',
  role: TestUserType.NORMAL // Editor is a normal user with edit rights
};

/**
 * All standard test users by TestUserType
 */
export const TEST_USERS = {
  [TestUserType.ADMIN]: DEFAULT_ADMIN_USER,
  [TestUserType.NORMAL]: DEFAULT_USER,
  [TestUserType.VIEWER]: DEFAULT_VIEWER
};

/**
 * Get user by role (for backward compatibility)
 * @param role User role to look up
 * @returns The corresponding test user
 */
export function getUserByRole(role: UserRole | string): TestUser {
  switch(role) {
    case UserRole.ADMIN:
    case 'ADMIN':
      return DEFAULT_ADMIN_USER;
    case UserRole.EDITOR:
    case 'EDITOR':
      return DEFAULT_EDITOR;
    case UserRole.VIEWER:
    case 'VIEWER':
      return DEFAULT_VIEWER;
    case UserRole.DEFAULT:
    case 'DEFAULT':
    default:
      return DEFAULT_ADMIN_USER;
  }
}

/**
 * Creates an authentication context for the given role
 * @param role User role to get context for
 * @returns Auth context with user ID
 */
export function getTestAuthCtx(role: UserRole = UserRole.DEFAULT) {
  const user = getUserByRole(role);
  return { userId: user.id };
}

/**
 * Currently active test user
 */
let currentUser = DEFAULT_ADMIN_USER;

/**
 * Sets up deterministic authentication
 * @param user Optional custom user to use (defaults to admin)
 */
export function setupDeterministicAuth(user: TestUser = DEFAULT_ADMIN_USER) {
  currentUser = user;
  
  // Mock clerk auth - can be imported from @clerk/nextjs or @clerk/nextjs/server
  vi.mock('@clerk/nextjs', () => ({
    auth: () => ({ userId: currentUser.id }),
    currentUser: () => Promise.resolve({
      id: currentUser.id,
      emailAddresses: [{ emailAddress: currentUser.email }],
      firstName: currentUser.name.split(' ')[0],
      lastName: currentUser.name.split(' ').slice(1).join(' ') || 'User',
      username: currentUser.email.split('@')[0],
      role: currentUser.role
    })
  }));
  
  vi.mock('@clerk/nextjs/server', () => ({
    auth: () => ({ userId: currentUser.id }),
    currentUser: () => Promise.resolve({
      id: currentUser.id,
      emailAddresses: [{ emailAddress: currentUser.email }],
      firstName: currentUser.name.split(' ')[0],
      lastName: currentUser.name.split(' ').slice(1).join(' ') || 'User',
      username: currentUser.email.split('@')[0],
      role: currentUser.role
    }),
    clerkClient: {
      users: {
        getUser: (userId: string) => Promise.resolve({ 
          id: userId,
          emailAddresses: [{ emailAddress: currentUser.email }],
          firstName: currentUser.name.split(' ')[0],
          lastName: currentUser.name.split(' ').slice(1).join(' ') || 'User'
        })
      }
    }
  }));
  
  return currentUser;
}

/**
 * Switches the current test user
 * @param userType Type of user to switch to
 * @returns The new current user
 */
export function switchUser(userType: TestUserType): TestUser {
  currentUser = TEST_USERS[userType];
  return currentUser;
}

/**
 * Gets the current test user
 */
export function getCurrentUser(): TestUser {
  return currentUser;
}

/**
 * Creates a mock authorization header with the current user's ID
 */
export function getAuthHeader(): HeadersInit {
  return {
    Authorization: `Bearer ${currentUser.id}`
  };
}
