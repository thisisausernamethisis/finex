-- Migration: Add embedding vector field to Chunk
ALTER TABLE "Chunk" ADD COLUMN "embedding" vector(1536) NULL DEFAULT NULL;
COMMENT ON COLUMN "Chunk"."embedding" IS 'OpenAI vector 1536-d';

-- Down Migration
-- ALTER TABLE "Chunk" DROP COLUMN "embedding";
