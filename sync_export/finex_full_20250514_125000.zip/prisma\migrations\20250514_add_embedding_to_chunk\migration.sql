-- Add embedding column to Chunk table with PostgreSQL vector(1536) type
ALTER TABLE "Chunk" ADD COLUMN "embedding" vector(1536);
