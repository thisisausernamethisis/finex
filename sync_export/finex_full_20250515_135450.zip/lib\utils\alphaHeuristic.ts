/**
 * Alpha Heuristic Utility
 * 
 * This utility calculates the optimal alpha value (weight between vector and keyword search)
 * based on query characteristics. It supports both heuristic-based and optional GPT-based tuning.
 */

import { logger } from '../logger';
import OpenAI from 'openai';
import { cacheGet, cacheSet } from '../services/cacheService';

// Cache TTL for alpha values (24 hours)
const ALPHA_CACHE_TTL = 86400;

// Default alpha if all else fails
const DEFAULT_ALPHA = 0.6;

// OpenAI client for GPT-based alpha tuning (optional)
let openai: OpenAI | null = null;

// Environment-based feature flag
const useGPTAdvisor = process.env.DYNAMIC_ALPHA_GPT === 'true';

if (useGPTAdvisor) {
  try {
    openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });
    logger.info('GPT-based alpha tuning enabled');
  } catch (err) {
    logger.warn('Failed to initialize OpenAI client for alpha tuning', { 
      error: err instanceof Error ? err.message : String(err) 
    });
  }
}

// Logger instance
const log = logger.child({ component: 'AlphaHeuristic' });

/**
 * Calculate optimal alpha value based on query characteristics
 * @deprecated Use calculateAlpha instead
 */
export async function pickAlpha(
  query?: string,
  domains?: string[],
): Promise<number> {
  return calculateAlpha(query || '', domains ? { domain: domains } : {});
}

/**
 * Calculate optimal alpha value based on query characteristics
 */
export async function calculateAlpha(
  query: string,
  options: { domain?: string | string[] } = {}
): Promise<number> {
  const domains = getDomains(options.domain);
  
  // Try to get cached alpha value for this query
  const cacheKey = `alpha:${query}:${domains.sort().join(',')}`;
  const cachedAlpha = await cacheGet<number>(cacheKey);
  
  if (cachedAlpha !== null) {
    log.debug('Using cached alpha value', { query, domains, alpha: cachedAlpha });
    return cachedAlpha;
  }
  
  // Compute alpha value
  let alpha: number;
  
  // Use GPT advisor if enabled and available
  if (useGPTAdvisor && openai) {
    try {
      alpha = await calculateGptAlpha(query, domains);
      log.info('Used GPT advisor for alpha', { query, alpha });
    } catch (err) {
      // Fall back to heuristic on GPT error
      log.warn('GPT alpha calculation failed, falling back to heuristic', { 
        error: err instanceof Error ? err.message : String(err) 
      });
      alpha = calculateHeuristicAlpha(query, domains);
    }
  } else {
    // Use heuristic approach
    alpha = calculateHeuristicAlpha(query, domains);
  }
  
  // Cache the result
  await cacheSet(cacheKey, alpha, ALPHA_CACHE_TTL);
  
  return alpha;
}

/**
 * Extract domains from various input formats
 */
function getDomains(domain?: string | string[]): string[] {
  if (!domain) return [];
  if (Array.isArray(domain)) return domain;
  return [domain];
}

/**
 * Calculate alpha by analyzing query with GPT
 */
async function calculateGptAlpha(
  query: string,
  domains: string[] = []
): Promise<number> {
  if (!openai) {
    throw new Error('OpenAI client not initialized');
  }
  
  // Build system prompt
  const systemPrompt = `
You are an expert in information retrieval, specialized in hybrid search systems.
Your task is to analyze a search query and determine the optimal balance (alpha value) between 
vector-based semantic search and keyword-based lexical search.

The alpha value ranges from 0.0 to 1.0:
- alpha = 1.0: Pure vector search (better for conceptual/semantic queries)
- alpha = 0.0: Pure keyword search (better for exact matches, codes, IDs)
- Values in between balance both approaches

Return ONLY a number between 0 and 1, with two decimal places.
`;

  // Prepare domain info if available
  const domainInfo = domains.length > 0 
    ? `\nQuery domain(s): ${domains.join(', ')}`
    : '';

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini', // Using smallest model for efficiency
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Search query: "${query}"${domainInfo}` }
      ],
      temperature: 0.1, // Low temperature for consistent results
      max_tokens: 10
    });
    
    const alphaText = response.choices[0].message.content?.trim() ?? '';
    const parsedAlpha = parseFloat(alphaText);
    
    if (isNaN(parsedAlpha) || parsedAlpha < 0 || parsedAlpha > 1) {
      throw new Error(`Invalid alpha value from GPT: ${alphaText}`);
    }
    
    return parsedAlpha;
  } catch (err) {
    log.error('Error in GPT alpha calculation', { 
      error: err instanceof Error ? err.message : String(err),
      query
    });
    throw err;
  }
}

/**
 * Calculate alpha using heuristic rules based on query characteristics
 */
export function calculateHeuristicAlpha(query: string = '', domains: string[] = []): number {
  // Start with a balanced alpha
  let alpha = 0.5;
  
  // Normalize query and extract features
  const normalizedQuery = query.toLowerCase().trim();
  const queryLength = normalizedQuery.length;
  const wordCount = normalizedQuery.split(/\s+/).length;
  
  // 1. Query length adjustments
  if (queryLength > 60) {
    alpha += 0.1; // Longer queries benefit from semantic understanding
  } else if (wordCount < 3) {
    alpha -= 0.15; // Very short queries favor keyword matching
  }
  
  // 2. Query content characteristics
  if (/["'].*["']/.test(query)) {
    alpha -= 0.2; // Quoted phrases strongly suggest exact matching
  }
  
  if (/\d{3,}/.test(query)) {
    alpha -= 0.1; // Queries with numbers favor keyword matching
  }
  
  if (/[\+\-\*\/\^\&\|\!\(\)\{\}\[\]\:\=\<\>]/.test(query)) {
    alpha -= 0.15; // Special characters suggest exact matching
  }
  
  // 3. Question detection
  if (/^(who|what|when|where|why|how)/.test(normalizedQuery)) {
    alpha += 0.15; // Questions favor semantic understanding
  }
  
  // 4. Domain-based adjustments
  if (domains.length > 0) {
    // Technical domains generally favor more exact matching
    const technicalDomains = ['CODE', 'TECHNICAL', 'LEGAL', 'REGULATORY'];
    if (domains.some(d => technicalDomains.includes(d.toUpperCase()))) {
      alpha -= 0.1;
    }
    
    // Conceptual domains favor semantic search
    const conceptualDomains = ['FINANCE', 'STRATEGY', 'ASSET', 'SCENARIO'];
    if (domains.some(d => conceptualDomains.includes(d.toUpperCase()))) {
      alpha += 0.05;
    }
  }
  
  // Ensure alpha stays in [0.2, 0.8] range for safety
  return Math.min(Math.max(alpha, 0.2), 0.8);
}

/**
 * Get explanation of alpha value for diagnostics
 */
export function explainAlpha(
  query: string, 
  alpha: number,
  domain?: string | string[]
): Record<string, any> {
  const domains = getDomains(domain);
  
  const explanation = {
    query,
    alpha,
    domains,
    queryFeatures: {
      length: query.length,
      wordCount: query.split(/\s+/).length,
      hasQuotes: /["'].*["']/.test(query),
      hasNumbers: /\d{3,}/.test(query),
      hasSpecialChars: /[\+\-\*\/\^\&\|\!\(\)\{\}\[\]\:\=\<\>]/.test(query),
      isQuestion: /^(who|what|when|where|why|how)/i.test(query.toLowerCase().trim()),
    },
    // If GPT-based, add source info
    source: useGPTAdvisor && openai ? 'gpt' : 'heuristic'
  };
  
  return explanation;
}
