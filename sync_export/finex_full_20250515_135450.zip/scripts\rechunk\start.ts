/**
 * Re-chunking utility to create new ChunkV2 entries with improved
 * chunking strategies (256 ± 15% tokens, 32-token overlap)
 * 
 * This script handles:
 * 1. Reading existing content from cards
 * 2. Splitting into better-sized chunks using advanced tokenization
 * 3. Creating new entries in ChunkV2 table
 * 4. (Optional) Generating embeddings for new chunks
 * 5. (Optional) Setting up dual-indexing for shadow rollout
 */

import { prisma } from '../../lib/db';
import { Prisma } from '@prisma/client';
import { logger } from '../../lib/logger';
import { generateDocEmbedding } from '../../lib/clients';
import { z } from 'zod';
import * as fs from 'fs/promises';
import * as path from 'path';
import { performance } from 'node:perf_hooks';

// Configure chunking parameters
const CHUNK_TARGET_SIZE = 256;        // Target tokens per chunk
const CHUNK_SIZE_VARIANCE = 0.15;     // Allow ±15% variance
const CHUNK_MIN_SIZE = Math.floor(CHUNK_TARGET_SIZE * (1 - CHUNK_SIZE_VARIANCE));
const CHUNK_MAX_SIZE = Math.ceil(CHUNK_TARGET_SIZE * (1 + CHUNK_SIZE_VARIANCE));
const CHUNK_OVERLAP = 32;             // Token overlap between chunks
const DEFAULT_BATCH_SIZE = 100;       // Cards to process per batch
const DEFAULT_EMBEDDING_BATCH = 20;   // Chunks to embed per batch (API rate limits)

// Logger instance
const log = logger.child({ component: 'Rechunker' });

// CLI argument schema
const ArgsSchema = z.object({
  batchSize: z.coerce.number().int().positive().default(DEFAULT_BATCH_SIZE),
  limit: z.coerce.number().int().positive().optional(),
  dryRun: z.boolean().default(false),
  embed: z.boolean().default(false),
  startId: z.string().optional(),
  domain: z.string().optional(),
  reindex: z.boolean().default(false),
}).partial();

/**
 * Main entry point
 */
async function main() {
  const args = parseArgs();
  
  log.info('Starting rechunking process', { 
    args, 
    chunkParams: { 
      target: CHUNK_TARGET_SIZE, 
      min: CHUNK_MIN_SIZE, 
      max: CHUNK_MAX_SIZE, 
      overlap: CHUNK_OVERLAP
    }
  });

  // Create ChunkV2 table if it doesn't exist
  if (!args.dryRun) {
    await ensureChunkV2TableExists();
  }
  
  // Get cards to process
  const startTime = performance.now();
  const totalCards = await prisma.card.count({
    where: args.startId ? { id: { gt: args.startId } } : undefined
  });
  
  log.info(`Found ${totalCards} cards to potentially process`, {
    startId: args.startId,
    limit: args.limit
  });

  // Process in batches
  let processedCards = 0;
  let processedChunks = 0;
  let currentId = args.startId || '';
  let shouldContinue = true;
  
  while (shouldContinue) {
    // Get next batch of cards
    const cards = await getCardBatch(currentId, args.batchSize, args.domain);
    
    if (cards.length === 0) {
      break;
    }
    
    log.info(`Processing batch of ${cards.length} cards`);
    
    // Process each card
    for (const card of cards) {
      const chunkCount = await processCard(card, args.dryRun);
      processedChunks += chunkCount;
      processedCards++;
      currentId = card.id;
      
      if (processedCards % 10 === 0) {
        log.info(`Progress update`, { 
          processedCards, 
          processedChunks,
          lastCardId: currentId
        });
      }
      
      // Check if we've reached the limit
      if (args.limit && processedCards >= args.limit) {
        shouldContinue = false;
        break;
      }
    }
    
    // Generate embeddings for new chunks if requested
    if (args.embed && !args.dryRun) {
      await generateEmbeddingsForLastBatch();
    }
  }
  
  const duration = (performance.now() - startTime) / 1000;
  
  log.info('Rechunking process completed', { 
    processedCards,
    processedChunks,
    durationSeconds: duration.toFixed(2),
    cardsPerSecond: (processedCards / duration).toFixed(2) 
  });
  
  // Output resumption command for convenience
  if (processedCards > 0) {
    const resumeCommand = `npm run rechunk:start -- --startId="${currentId}"${args.embed ? ' --embed' : ''}${args.domain ? ` --domain="${args.domain}"` : ''}`;
    log.info(`To resume, run: ${resumeCommand}`);
  }
  
  await writeSummaryFile({
    timestamp: new Date().toISOString(),
    processedCards,
    processedChunks,
    durationSeconds: duration,
    lastCardId: currentId,
    args
  });
}

/**
 * Parse command line arguments
 */
function parseArgs() {
  const args = process.argv.slice(2).reduce((acc, arg) => {
    if (arg.startsWith('--')) {
      const [key, value] = arg.substring(2).split('=');
      if (value === undefined) {
        acc[key] = true;
      } else {
        acc[key] = value;
      }
    }
    return acc;
  }, {} as Record<string, any>);
  
  try {
    return ArgsSchema.parse(args);
  } catch (error) {
    log.error('Invalid arguments', { error });
    process.exit(1);
  }
}

/**
 * Ensure the ChunkV2 table exists
 */
async function ensureChunkV2TableExists() {
  try {
    // Check if table exists by trying to query against it
    await prisma.$queryRaw`SELECT 1 FROM "ChunkV2" LIMIT 1`;
    log.info('ChunkV2 table already exists');
  } catch (error) {
    log.info('Creating ChunkV2 table');
    
    // Create table with Prisma raw query (idempotent)
    await prisma.$executeRaw`
      CREATE TABLE IF NOT EXISTS "ChunkV2" (
        "id" TEXT NOT NULL,
        "content" TEXT NOT NULL,
        "card_id" TEXT NOT NULL REFERENCES "Card"("id") ON DELETE CASCADE,
        "domain" TEXT,
        "embedding" vector(1536),
        "chunk_index" INTEGER NOT NULL,
        "token_count" INTEGER NOT NULL,
        "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        
        CONSTRAINT "ChunkV2_pkey" PRIMARY KEY ("id")
      );
      
      CREATE INDEX IF NOT EXISTS "ChunkV2_card_id_idx" ON "ChunkV2"("card_id");
      CREATE INDEX IF NOT EXISTS "ChunkV2_domain_idx" ON "ChunkV2"("domain");
    `;
  }
}

/**
 * Get next batch of cards to process
 */
async function getCardBatch(
  startId: string, 
  batchSize: number,
  domain?: string
): Promise<Array<{ id: string; content: string; theme_id: string; }>> {
  const whereClause: any = {};
  
  if (startId) {
    whereClause.id = { gt: startId };
  }
  
  // Add domain filter if specified
  if (domain) {
    whereClause.theme = {
      domain: domain
    };
  }
  
  const cards = await prisma.card.findMany({
    where: whereClause,
    select: {
      id: true,
      content: true,
      theme_id: true
    },
    orderBy: { id: 'asc' },
    take: batchSize
  });
  
  return cards;
}

/**
 * Process a card by splitting into chunks and storing in ChunkV2
 */
async function processCard(
  card: { id: string; content: string; theme_id: string },
  dryRun: boolean
): Promise<number> {
  // Get domain from theme
  const theme = await prisma.theme.findUnique({
    where: { id: card.theme_id },
    select: { domain: true }
  });
  
  const domain = theme?.domain || null;
  
  // Split content into chunks
  const chunks = splitIntoChunks(card.content);
  
  if (chunks.length === 0) {
    log.warn(`No chunks generated for card ${card.id}`);
    return 0;
  }
  
  log.debug(`Generated ${chunks.length} chunks for card ${card.id}`, {
    cardId: card.id,
    chunkCount: chunks.length,
    domain
  });
  
  // In dry run mode, just log and return
  if (dryRun) {
    log.info(`[DRY RUN] Would insert ${chunks.length} chunks for card ${card.id}`);
    return chunks.length;
  }
  
  // Store chunks in ChunkV2 table
  try {
    // Check if chunks already exist for this card
    const existingChunks = await prisma.chunkV2.count({
      where: { card_id: card.id }
    });
    
    if (existingChunks > 0) {
      log.debug(`Card ${card.id} already has chunks, skipping`);
      return 0;
    }
    
    // Insert new chunks
    await prisma.$transaction(
      chunks.map((chunk, index) => 
        prisma.chunkV2.create({
          data: {
            id: `${card.id}-chunk-${index}`,
            content: chunk.text,
            card_id: card.id,
            domain,
            chunk_index: index,
            token_count: chunk.tokens
          }
        })
      )
    );
    
    return chunks.length;
  } catch (error) {
    log.error(`Error storing chunks for card ${card.id}`, { 
      error: error instanceof Error ? error.message : String(error),
      cardId: card.id
    });
    return 0;
  }
}

/**
 * Split text into chunks with target size and overlap
 */
function splitIntoChunks(text: string): Array<{ text: string; tokens: number }> {
  if (!text || text.trim().length === 0) {
    return [];
  }
  
  // Simple implementation - in a real system, use a proper tokenizer
  // This is a naive approximation that assumes 4 characters per token on average
  const CHARS_PER_TOKEN = 4;
  const targetChars = CHUNK_TARGET_SIZE * CHARS_PER_TOKEN;
  const overlapChars = CHUNK_OVERLAP * CHARS_PER_TOKEN;
  const minChars = CHUNK_MIN_SIZE * CHARS_PER_TOKEN;
  
  // Split by paragraphs first
  const paragraphs = text.split(/\n\s*\n/);
  const chunks: Array<{ text: string; tokens: number }> = [];
  let currentChunk = '';
  
  for (const para of paragraphs) {
    // If adding this paragraph would exceed max size, finish current chunk
    if (currentChunk.length + para.length > targetChars && currentChunk.length >= minChars) {
      const tokens = Math.round(currentChunk.length / CHARS_PER_TOKEN);
      chunks.push({ text: currentChunk, tokens });
      
      // Start new chunk with overlap from previous chunk
      const words = currentChunk.split(' ');
      const overlapText = words.slice(-Math.ceil(overlapChars / 5)).join(' ');
      currentChunk = overlapText + '\n\n' + para;
    } else {
      // Add paragraph to current chunk with a separator
      if (currentChunk) {
        currentChunk += '\n\n';
      }
      currentChunk += para;
    }
  }
  
  // Don't forget the last chunk
  if (currentChunk) {
    const tokens = Math.round(currentChunk.length / CHARS_PER_TOKEN);
    chunks.push({ text: currentChunk, tokens });
  }
  
  return chunks;
}

/**
 * Generate embeddings for the last batch of chunks that were inserted
 */
async function generateEmbeddingsForLastBatch() {
  // Get chunks without embeddings
  const chunks = await prisma.chunkV2.findMany({
    where: { embedding: null },
    select: { id: true, content: true },
    take: DEFAULT_EMBEDDING_BATCH
  });
  
  if (chunks.length === 0) {
    return;
  }
  
  log.info(`Generating embeddings for ${chunks.length} chunks`);
  
  for (const chunk of chunks) {
    try {
      const embedding = await generateDocEmbedding(chunk.content);
      
      await prisma.chunkV2.update({
        where: { id: chunk.id },
        data: { embedding }
      });
      
      // Small delay to avoid rate limits
      await new Promise(resolve => setTimeout(resolve, 100));
    } catch (error) {
      log.error(`Error generating embedding for chunk ${chunk.id}`, { 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  }
}

/**
 * Write summary file with information about this run
 */
async function writeSummaryFile(summary: any) {
  try {
    const filename = `rechunk-summary-${new Date().toISOString().replace(/:/g, '-')}.json`;
    const filePath = path.join(__dirname, 'logs', filename);
    
    // Make sure the logs directory exists
    await fs.mkdir(path.join(__dirname, 'logs'), { recursive: true });
    
    await fs.writeFile(filePath, JSON.stringify(summary, null, 2));
    log.info(`Summary written to ${filePath}`);
  } catch (error) {
    log.error('Failed to write summary file', { 
      error: error instanceof Error ? error.message : String(error) 
    });
  }
}

// Run main function if this is the main module
if (require.main === module) {
  main().catch(err => {
    log.error('Fatal error in rechunker', { 
      error: err instanceof Error ? err.message : String(err) 
    });
    process.exit(1);
  });
}

// Export functions for use in other modules
export { 
  splitIntoChunks,
  processCard, 
  main as rechunk 
};
