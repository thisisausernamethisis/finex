/*
ANN Index Tuning SQL Generator for pgvector
This script generates SQL commands for parameter tuning of 
IVF (Inverted File) and HNSW (Hierarchical Navigable Small World) indices.

Parameters:
- IVF: number of lists, number of probes
- HNSW: m connections, ef_construction

Usage:
1. Run the generated SQL in a test database
2. Compare the recall, build time, and query time metrics
3. Select the best parameters for production
*/

-- Clear previous test results
DROP TABLE IF EXISTS ann_index_benchmark;
CREATE TABLE ann_index_benchmark (
    id SERIAL PRIMARY KEY,
    index_type VARCHAR(10) NOT NULL,  -- 'ivf' or 'hnsw'
    params JSONB NOT NULL,            -- Parameters used for the index
    build_time_ms INTEGER,            -- Time taken to build the index
    avg_query_time_ms FLOAT,          -- Average time per query
    avg_recall FLOAT,                 -- Recall@10 (compared to exact search)
    notes TEXT,                       -- Any additional observations
    created_at TIMESTAMP DEFAULT NOW()
);

-- Define benchmark queries (representative workload)
DROP TABLE IF EXISTS benchmark_queries;
CREATE TABLE benchmark_queries (
    id SERIAL PRIMARY KEY,
    query_text TEXT NOT NULL,
    embedding VECTOR(1536) NOT NULL
);

-- Insert some representative queries
-- In a real scenario, these would be taken from production query logs
INSERT INTO benchmark_queries (query_text, embedding)
SELECT 
    'Query ' || generate_series,
    ARRAY_AGG(random() * 2 - 1)::VECTOR(1536)
FROM generate_series(1, 20),
     generate_series(1, 1536)
GROUP BY generate_series;

-- Function to run a benchmark for a specific index configuration
CREATE OR REPLACE FUNCTION benchmark_ann_index(
    p_index_type TEXT,
    p_params JSONB,
    p_sample_size INTEGER DEFAULT 1000
) RETURNS TABLE (
    build_time_ms INTEGER,
    avg_query_time_ms FLOAT,
    avg_recall FLOAT
) AS $$
DECLARE
    v_build_start TIMESTAMP;
    v_build_end TIMESTAMP;
    v_exact_results JSONB;
    v_approx_results JSONB;
    v_index_name TEXT;
    v_create_index_sql TEXT;
    v_drop_index_sql TEXT;
    v_temp_table TEXT := 'tmp_benchmark_chunks';
BEGIN
    -- Create temporary copy of data for benchmarking
    EXECUTE 'CREATE TEMP TABLE ' || v_temp_table || ' AS SELECT id, embedding FROM "Chunk" WHERE embedding IS NOT NULL LIMIT ' || p_sample_size;
    
    -- Generate index name based on parameters
    v_index_name := p_index_type || '_benchmark_idx';
    
    -- Build the index creation SQL based on index type
    IF p_index_type = 'ivf' THEN
        v_create_index_sql := format(
            'CREATE INDEX %s ON %s USING ivfflat (embedding vector_l2_ops) WITH (lists = %s)',
            v_index_name,
            v_temp_table,
            p_params->>'lists'
        );
    ELSIF p_index_type = 'hnsw' THEN
        v_create_index_sql := format(
            'CREATE INDEX %s ON %s USING hnsw (embedding vector_l2_ops) WITH (m = %s, ef_construction = %s)',
            v_index_name,
            v_temp_table,
            p_params->>'m',
            p_params->>'ef_construction'
        );
    ELSE
        RAISE EXCEPTION 'Unsupported index type: %', p_index_type;
    END IF;
    
    v_drop_index_sql := 'DROP INDEX IF EXISTS ' || v_index_name;
    
    -- First get exact search results for reference
    v_exact_results := (
        SELECT jsonb_object_agg(q.id, (
            SELECT jsonb_agg(c.id) 
            FROM (
                SELECT id, 1 - (embedding <=> q.embedding) AS similarity
                FROM tmp_benchmark_chunks
                ORDER BY embedding <=> q.embedding
                LIMIT 10
            ) c
        ))
        FROM benchmark_queries q
    );
    
    -- Build the index and measure time
    v_build_start := clock_timestamp();
    EXECUTE v_drop_index_sql;
    EXECUTE v_create_index_sql;
    v_build_end := clock_timestamp();
    
    -- Configure the index parameters for search (IVF probes)
    IF p_index_type = 'ivf' THEN
        EXECUTE 'SET ivfflat.probes = ' || (p_params->>'probes');
    END IF;
    
    -- Measure query time and recall
    v_approx_results := (
        WITH approx_search AS (
            SELECT 
                q.id AS query_id,
                c.id AS chunk_id,
                row_number() OVER (PARTITION BY q.id ORDER BY embedding <=> q.embedding) AS rank
            FROM benchmark_queries q
            CROSS JOIN LATERAL (
                SELECT id, embedding
                FROM tmp_benchmark_chunks
                ORDER BY embedding <=> q.embedding
                LIMIT 10
            ) c
        )
        SELECT jsonb_object_agg(query_id, jsonb_agg(chunk_id))
        FROM approx_search
        GROUP BY query_id
    );
    
    -- Calculate average recall
    WITH recall_calc AS (
        SELECT 
            q.key::INT AS query_id,
            (
                SELECT count(*)
                FROM jsonb_array_elements_text(q.value) exact_id
                JOIN jsonb_array_elements_text(a.value) approx_id
                    ON exact_id = approx_id
            )::FLOAT / 10 AS recall  -- Recall@10: how many of the top 10 exact results were found
        FROM jsonb_each(v_exact_results) q
        JOIN jsonb_each(v_approx_results) a ON q.key = a.key
    )
    SELECT 
        EXTRACT(EPOCH FROM (v_build_end - v_build_start)) * 1000,
        (SELECT avg(EXTRACT(EPOCH FROM duration)) * 1000 
         FROM (
             SELECT clock_timestamp() - clock_timestamp() AS duration
             FROM benchmark_queries q
             CROSS JOIN LATERAL (
                 SELECT id FROM tmp_benchmark_chunks 
                 ORDER BY embedding <=> q.embedding LIMIT 10
             ) c
         ) t),
        (SELECT avg(recall) FROM recall_calc)
    INTO build_time_ms, avg_query_time_ms, avg_recall;
    
    -- Clean up
    EXECUTE v_drop_index_sql;
    DROP TABLE IF EXISTS tmp_benchmark_chunks;
    
    RETURN NEXT;
END;
$$ LANGUAGE plpgsql;

-- Generate SQL for IVF parameter sweep
WITH ivf_params AS (
    SELECT 
        lists, 
        probes
    FROM 
        generate_series(8, 512, CASE WHEN generate_series < 64 THEN 8 ELSE 32 END) AS lists,
        generate_series(1, 100, CASE WHEN generate_series < 10 THEN 1 ELSE 5 END) AS probes
    WHERE
        -- Avoid unreasonable combinations
        probes <= lists
        AND lists <= 512  -- Keep max reasonable for our dataset size
)
SELECT format(
    'INSERT INTO ann_index_benchmark (index_type, params, build_time_ms, avg_query_time_ms, avg_recall) 
     SELECT ''ivf'', ''%s'', * FROM benchmark_ann_index(''ivf'', ''%s'');',
    jsonb_build_object('lists', lists, 'probes', probes),
    jsonb_build_object('lists', lists, 'probes', probes)
)
FROM ivf_params
LIMIT 20;  -- Generate top 20 combinations to test

-- Generate SQL for HNSW parameter sweep
WITH hnsw_params AS (
    SELECT 
        m,
        ef_construction
    FROM 
        generate_series(8, 64, 4) AS m,
        generate_series(40, 400, 40) AS ef_construction
    WHERE
        -- Maintain reasonable cost constraints
        ef_construction >= m * 2
)
SELECT format(
    'INSERT INTO ann_index_benchmark (index_type, params, build_time_ms, avg_query_time_ms, avg_recall) 
     SELECT ''hnsw'', ''%s'', * FROM benchmark_ann_index(''hnsw'', ''%s'');',
    jsonb_build_object('m', m, 'ef_construction', ef_construction),
    jsonb_build_object('m', m, 'ef_construction', ef_construction)
)
FROM hnsw_params
LIMIT 15;  -- Generate top 15 combinations to test

-- Query to analyze results and find optimal parameters
-- Higher weight for recall, but balance with query time
SELECT 
    index_type,
    params,
    build_time_ms,
    avg_query_time_ms,
    avg_recall,
    -- Scoring formula giving 70% weight to recall and 30% to speed
    (avg_recall * 0.7) + ((1.0 / (avg_query_time_ms + 1)) * 0.3) AS score
FROM 
    ann_index_benchmark
ORDER BY 
    score DESC;

-- TODO: Add RAG evaluation metrics when the RAGAS benchmark is ready
-- This will measure the end-to-end improvements in:
-- 1. Answer relevance
-- 2. Context precision
-- 3. Faithfulness to source documents
-- 4. End-user satisfaction
