// Re-export alphaHeuristic functionality for backward compatibility
import { pickAlpha } from './alphaHeuristic';
export { pickAlpha };

type Hit = { id: string; score: number };

/**
 * Interface for alpha scoring options
 */
export interface AlphaOptions {
  query?: string;            // The search query text
  domain?: string;           // Single domain (for backward compatibility)
  domains?: string[];        // Multiple domains array
  alpha?: number;            // Explicit alpha override
  useGPT?: boolean;          // Whether to use GPT for scoring (default: follows env var)
}

/**
 * Merges vector and keyword search results with dynamic alpha weighting
 * 
 * @param vec Vector search results
 * @param kw Keyword/BM25 search results
 * @param options Scoring options including domain and explicit alpha
 * @returns Promise resolving to merged results sorted by score
 */
export async function scoreMerge(
  vec: Hit[],
  kw: Hit[],
  { domain, alpha, query }: { domain?: string; alpha?: number; query?: string }
) {
  // Use explicit alpha if provided, otherwise compute dynamically
  const α = alpha !== undefined ? alpha : await pickAlpha(query, domain ? [domain] : undefined);
  const byId = new Map<string, number>();

  for (const h of vec) byId.set(h.id, (byId.get(h.id) ?? 0) + α * h.score);
  for (const h of kw)  byId.set(h.id, (byId.get(h.id) ?? 0) + (1 - α) * h.score);

  return Array.from(byId.entries())
    .map(([id, score]) => ({ id, score }))
    .sort((a, b) => b.score - a.score);
}
