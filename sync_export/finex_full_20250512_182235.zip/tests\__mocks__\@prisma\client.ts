import { AssetKind } from '../../mocks/prisma';
export { AssetKind };
export const Prisma = { AssetKind: AssetKind } as any;
