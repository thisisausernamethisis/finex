import { vi } from 'vitest';

export enum AssetKind { STANDARD='STANDARD', PREMIUM='PREMIUM' }
export const Prisma = { AssetKind } as any;

/* tiny async helper */
const a = <T = unknown>(v?: T) => vi.fn().mockResolvedValue(v);

export const prisma = {
  themeTemplate: {
    findUnique: a(null),
    findMany:   a([]),
    create:     a({}),
    update:     a({}),
    delete:     a(),
    upsert:     a({}),
    count:      a(0),
  },
  asset: {
    findUnique: a(null),
    findMany:   a([]),
    create:     a({}),
    update:     a({}),
    delete:     a(),
    deleteMany: a({ count: 0 }),
    count:      a(0),
  },
  card: {
    findUnique: a(null),
    findMany:   a([]),
    create:     a({}),
    update:     a({}),
    delete:     a(),
  },
  theme: {
    findUnique: a(null),
    findMany:   a([]),
    create:     a({}),
    update:     a({}),
    delete:     a(),
    count:      a(0),
  },
  matrixAnalysisResult: {
    findUnique: a(null),
    update:     a({}),
    create:     a({}),
    count:      a(0),
  },
  $transaction: a([]),
  $connect:     a(),
  $disconnect:  a(),
} as any;
