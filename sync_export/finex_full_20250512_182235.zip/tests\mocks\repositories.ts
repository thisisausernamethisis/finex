/**
 * Vitest fixture mock focused on AssetRepository contract behaviour.
 * Other repositories are mocked in tests/__mocks__/lib/repositories.ts.
 */
import { vi } from 'vitest';
import type { Asset, AssetKind } from '@prisma/client';
import { paginate, filterAssets } from '../shared/mockHelpers';
import { isOwner } from '../../lib/rbac';

// Using any to bypass the strict typing during the migration from userId to ownerId
const store: any[] = [
  {
    id: 'mock-asset-1',
    name: 'Mock Asset 1',
    ownerId: 'user_test123',
    description: null,
    growthValue: null,
    kind: 'STANDARD' as AssetKind,
    sourceTemplateId: null,
    isPublic: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'mock-asset-2',
    name: 'Mock Asset 2',
    ownerId: 'user_other',
    description: null,
    growthValue: null,
    kind: 'STANDARD' as AssetKind,
    sourceTemplateId: null,
    isPublic: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

export const AssetRepository = vi.fn().mockImplementation(() => ({
  listAssets: vi.fn(
    async ({
      page,
      limit,
      q,
      mine,
      userId: ownerId,
    }: {
      page: number; limit: number; q?: string; mine?: boolean; userId: string;
    }) => {
      const filtered = filterAssets(store, { q, mine, userId: ownerId });
      return paginate(filtered, page, limit);
    },
  ),
  getAssetById: vi.fn(async (id: string, ownerId?: string) => {
    const asset = store.find(a => a.id === id) ?? null;
    
    // Apply RBAC: return null if asset not found or user doesn't have access
    if (!asset) return null;
    if (ownerId && !asset.isPublic && !isOwner(ownerId, asset)) return null;
    
    return asset;
  }),
  createAsset: vi.fn(async (_ownerId: string, data: Partial<Asset>) => {
    const asset = { ...data, id: `mock-asset-${Date.now()}` } as Asset;
    store.push(asset);
    return asset;
  }),
  updateAsset: vi.fn(async (id: string, data: Partial<Asset>, ownerId?: string) => {
    const idx = store.findIndex(a => a.id === id);
    // Check if asset exists and user is the owner
    if (idx === -1) return null;
    if (ownerId && !isOwner(ownerId, store[idx])) return null;
    store[idx] = { ...store[idx], ...data, updatedAt: new Date() };
    return store[idx];
  }),
  deleteAsset: vi.fn(async (id: string, ownerId?: string) => {
    const idx = store.findIndex(a => a.id === id);
    // Check if asset exists and user is the owner
    if (idx === -1) return false;
    if (ownerId && !isOwner(ownerId, store[idx])) return false;
    
    store.splice(idx, 1);
    return true;
  }),
  assetExists: vi.fn(async (id: string) => store.some(a => a.id === id)),
}));

/* Placeholder exports for legacy imports */
export const ThemeTemplateRepository = vi.fn();
export const ScenarioRepository = vi.fn();
export const ThemeRepository = vi.fn();
export const CardRepository = vi.fn();
export const MatrixRepository = vi.fn();
