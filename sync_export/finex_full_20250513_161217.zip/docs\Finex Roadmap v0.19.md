# Finex Roadmap v0.19 — Retrieval & Prompting Overhaul

*Last updated 2025‑05‑13*

This single roadmap **supersedes** all older fragments (`Finex Roadmap v0.18`, `v0.17`, etc.). It merges every micro‑revision and audit note into one authoritative view.

---

## 0 · Bird's‑eye timeline

| Phase                     | Target ETA   | Primary goal                                                    | Status      |
| ------------------------- | ------------ | --------------------------------------------------------------- | ----------- |
| 0.0 Bootstrap             | 2024‑11      | Mono‑repo, CI skeleton, Postgres + Next 14                      | 🟢          |
| 1.0 Domain Models         | 2024‑12      | Assets · Scenarios · Templates ERD + seed                       | 🟢          |
| 2.0 Auth & API            | 2025‑01      | Clerk JWT flow · OpenAPI contract v0.8                          | 🟢          |
| 3.0 Template‑Library MVP  | 2025‑02      | CRUD, library search, RBAC                                      | 🟢          |
| 4.0 Matrix Engine         | 2025‑03      | BullMQ worker + impact scores                                   | 🟢          |
| 5.0 Hardening Wrap‑up     | 2025‑04      | Deterministic IDs, basic docs                                   | 🟢          |
| 6.1 Green CI              | 2025‑05      | Unit + contract pipelines green, ≥ 70 % cov., validation & RBAC | 🟢 (closed) |
| 6.2 DI Refactor           | 2025‑05      | Injectable Prisma + unified mocks                               | 🟢 (closed) |
| 6.3 API & Schema Security | 2025‑05      | RBAC hardening, OpenAPI diff gate, schema constraints, ≥ 80% cov| 🟢 (closed) |
| 6.4 RAG Uplift            | 2025‑05      | RAGAS ≥ 0.80, analyst preview                                   | 🟢 (closed) |
| 6.5 CI Matrix Split       | 2025‑06      | Parallel unit/E2E, reduce build times                           | ⚪           |
| 7.1 Retrieval & Prompting | 2025‑06      | Domain-aware search, CoT prompting, perf ≤ 1s P95               | ⚪           |

---

## 1 · Phase summaries

### Phase 6.4 — **RAG Uplift** (🟢 Closed)

| Epic                       | Outcome                               | Ticket | Owner       | Status |
| -------------------------- | ------------------------------------- | ------ | ----------- | ------ |
| 6.4‑a Evaluation Harness   | RAGAS metric calculation & CI step    | T‑260  | @ai-infra   | 🟢     |
| 6.4‑b Gold QA Dataset      | 50 rows of questions/answers for eval | T‑264  | @qa         | 🟢     |
| 6.4‑c Redis Cache          | Hybrid search caching for performance | T‑261  | @perf       | 🟢     |
| 6.4‑d Matrix Enhancements  | Summary & confidence score in worker  | T‑262  | @ai-core    | 🟢     |
| 6.4‑e Cache Integration    | Unit and integration tests for cache  | T‑265  | @testing    | 🟢     |
| 6.4‑f Preview Endpoint     | Lightweight matrix result API         | T‑266  | @api        | 🟢     |
| 6.4‑g Prometheus Metrics   | RAG cache observability counters      | T‑267  | @ops        | 🟢     |
| 6.4‑h Documentation        | Runbook and release notes             | T‑268  | @docs       | 🟢     |

**Exit criteria** for Phase 6.4:

1. RAGAS evaluation harness implemented with ≥ 0.80 threshold
2. Gold QA dataset with 50 rows for evaluation
3. Redis cache integrated and optimized for repeat queries (<100ms)
4. Matrix worker enhanced with summary generation and confidence scoring
5. Preview endpoint providing fast access to matrix analysis summaries
6. Prometheus metrics for observability of the RAG system
7. Comprehensive documentation in runbooks and CHANGELOG

### Phase 6.5 — **CI Matrix Split** (⚪ In Progress)

| Epic                       | Outcome                               | Ticket | Owner       | Status |
| -------------------------- | ------------------------------------- | ------ | ----------- | ------ |
| 6.5‑a Parallel Testing     | Run unit and E2E tests in parallel    | T‑261  | @build      | ⚪      |
| 6.5‑b Build Cache Strategy | Improve caching for faster builds     |        | @build      | ⚪      |

### Phase 7.1 — **Retrieval & Prompting Overhaul** (⚪ Planned)

| Epic                             | Outcome                                         | Ticket | Owner       | Status |
| -------------------------------- | ----------------------------------------------- | ------ | ----------- | ------ |
| 7.1‑a Roadmap Bump               | Update Roadmap to v0.19 with Phase 7.1          | T‑306  | @docs       | 🟡     |
| 7.1‑b Domain Column Addition     | Add domain enum to Chunk model                  | T‑301a | @data       | ⚪      |
| 7.1‑c Parallel Search            | Run BM25 & vector queries in parallel           | T‑305  | @perf       | ⚪      |
| 7.1‑d Domain-Aware Search        | Add domain filter & configurable α to search    | T‑302  | @ai-infra   | ⚪      |
| 7.1‑e Dynamic Alpha              | Add heuristic query analyzer + optional advisor | T‑303  | @ai-core    | ⚪      |
| 7.1‑f CoT Function Prompt        | Implement Chain-of-Thought + function calling   | T‑304  | @ai-core    | ⚪      |
| 7.1‑g Re-Chunk & Re-Index        | Re-chunk corpus to 256 ± 15% tokens            | T‑301b | @data       | ⚪      |

**Exit criteria** for Phase 7.1:

1. Domain awareness added to chunk model and search service
2. Search performance improved through parallelization (≤ 50ms median latency)
3. Query type detection with dynamic α adjustment
4. Chain-of-Thought prompting with function calling implemented
5. Corpus re-chunked to 256 ± 15% tokens with domain assignment
6. RAGAS metrics showing improvement on gold set (precision, recall, answer_relevance, faithfulness)
7. End-to-end response time ≤ 1s P95 with ANN config using ivfflat (lists=100) on Neon

---

## 2 · Open ticket snapshot

| ID    | Phase | Description                                   | Blockers          | Status |
| ----- | ----- | --------------------------------------------- | ----------------- | ------ |
| T‑261 | 6.5   | CI Matrix Split for parallel test runs        | -                 | ⚪      |
| T‑306 | 7.1   | Roadmap bump to v0.19                         | -                 | 🟡     |
| T‑301a| 7.1   | Add domain column to Chunk model              | -                 | ⚪      |
| T‑305 | 7.1   | Run BM25 & vector queries in parallel         | -                 | ⚪      |
| T‑302 | 7.1   | Domain-aware hybrid search                    | T‑301a            | ⚪      |
| T‑303 | 7.1   | Dynamic alpha with heuristic scorer           | T‑302             | ⚪      |
| T‑304 | 7.1   | CoT function prompt for matrix worker         | -                 | ⚪      |
| T‑301b| 7.1   | Re-chunk corpus and regenerate embeddings     | T‑301a, T‑305     | ⚪      |

Closed: T-260 (RAG evaluation), T-261 (Redis cache), T-262 (Matrix enhancements), T-264 (Gold QA), T-265 (Cache tests), T-266 (Preview endpoint), T-267 (Metrics), T-268 (Documentation) as of v0.18.

---

## 3 · Recent commits (since v0.18)

| Hash     | Date       | Title                                       |
| -------- | ---------- | ------------------------------------------- |
| g3h4i5j6 | 2025‑05‑13 | docs(roadmap): bump to v0.19 with Phase 7.1 |

---

## 4 · Next concrete actions

1. **Implement** `T-306` – Create Finex Roadmap v0.19 with Phase 7.1 milestones (this document)
2. **Implement** `T-301a` – Add domain enum to Chunk model with zero-downtime migration
3. **Implement** `T-305` – Run BM25 & vector queries in parallel, expose k parameter
4. **Implement** `T-302` – Extend searchService with domain filter & configurable α
5. **Implement** `T-303` – Add heuristic scorer + optional GPT-3.5 advisor for dynamic α
6. **Implement** `T-304` – Replace worker prompt with CoT + OpenAI function call
7. **Implement** `T-301b` – Re-chunk corpus to 256 ± 15% tokens, regenerate embeddings
8. **Branch** `phase6.5/ci_matrix_split` – implement improved parallel testing

---

## 5 · Phase 7.1 Implementation Guard-Rails

**Contract-first**: OpenAPI remains unchanged in 7.1; only internal worker & search logic evolve.

**One-task-one-PR**: Each YAML ticket touches ≤ 5 files; CI must stay green after each merge.

**Data migration**: Schema change = add domain varchar to Chunk; provide migration & backfill script.

**Heuristic α**: Start with regex counts ([A-Z][a-z]+ proper nouns, digits) → α_BM25 = 0.75 else 0.5.

**Advisor call**: Wrap in feature flag DYNAMIC_ALPHA_GPT=true to avoid cost during tests.

**Prompt**: Include hidden "reasoning_steps" key; strip before persisting MatrixAnalysisResult.

**Perf budget**: Keep end-to-end ≤ 1s P95; ANN config CREATE INDEX … USING ivfflat (lists=100) on Neon.

---

## appendix – audit cross‑reference

All items flagged in *Finex Project Audit (Mid‑Phase 6)* have been addressed:
- The DI container implementation, SQLite test harness, and unified mock registry (v0.16) directly address dependency management.
- RBAC helpers, rate limit mock parity, and type safety improvements (v0.17) address security recommendations.
- Coverage boost to 80% meets the audit's quality gate requirements.
- RAG system uplift with caching and metrics (v0.18) addresses performance and observability recommendations.
