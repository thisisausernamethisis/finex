# Finex Roadmap v0.18 — RAG Uplift

*Last updated 2025‑05‑13*

This single roadmap **supersedes** all older fragments (`Finex Roadmap v0.17`, `v0.16`, etc.). It merges every micro‑revision and audit note into one authoritative view.

---

## 0 · Bird's‑eye timeline

| Phase                    | Target ETA   | Primary goal                                                    | Status      |
| ------------------------ | ------------ | --------------------------------------------------------------- | ----------- |
| 0.0 Bootstrap            | 2024‑11      | Mono‑repo, CI skeleton, Postgres + Next 14                      | 🟢          |
| 1.0 Domain Models        | 2024‑12      | Assets · Scenarios · Templates ERD + seed                       | 🟢          |
| 2.0 Auth & API           | 2025‑01      | Clerk JWT flow · OpenAPI contract v0.8                          | 🟢          |
| 3.0 Template‑Library MVP | 2025‑02      | CRUD, library search, RBAC                                      | 🟢          |
| 4.0 Matrix Engine        | 2025‑03      | BullMQ worker + impact scores                                   | 🟢          |
| 5.0 Hardening Wrap‑up    | 2025‑04      | Deterministic IDs, basic docs                                   | 🟢          |
| 6.1 Green CI             | 2025‑05      | Unit + contract pipelines green, ≥ 70 % cov., validation & RBAC | 🟢 (closed) |
| 6.2 DI Refactor          | 2025‑05      | Injectable Prisma + unified mocks                               | 🟢 (closed) |
| 6.3 API & Schema Security| 2025‑05      | RBAC hardening, OpenAPI diff gate, schema constraints, ≥ 80% cov| 🟢 (closed) |
| 6.4 RAG Uplift           | 2025‑05      | RAGAS ≥ 0.80, analyst preview                                   | 🟢 (closed) |
| 6.5 CI Matrix Split      | 2025‑06      | Parallel unit/E2E, reduce build times                           | ⚪           |

---

## 1 · Phase summaries

### Phase 6.1 — **Green CI** (🟢 Closed)

* **Contract suites** green after validation + RBAC patch.
* **Coverage** 71.3 %.
* All `@ts-nocheck` banners purged outside legacy proto.
* OpenAPI diff stub installed (real diff will land in 6.3).

### Phase 6.2 — **DI Refactor & Mock Unification** (🟢 Closed)

| Epic                       | Outcome                              | Ticket | Owner       | Status |
| -------------------------- | ------------------------------------ | ------ | ----------- | ------ |
| 6.2‑a Injectable Prisma    | DI container token, swap SQLite/mock | T‑220  | @arch       | 🟢     |
| 6.2‑b Single mock registry | Remove `tests/mocks/*` duplication   | T‑223  | @qa         | 🟢     |
| 6.2‑c Alias cleanup        | Unified `@/` path for prod & tests   | T‑224  | @build      | 🟢     |
| 6.2‑d Seed harness         | In‑memory SQLite for contract suite  | T‑225  | @data‑infra | 🟢     |
| 6.2‑e Final type‑safety    | Remove remaining `@ts-expect-error`  | T‑231  | @all        | 🟢     |

### Phase 6.3 — **API & Schema Security** (🟢 Closed)

| Epic                       | Outcome                               | Ticket | Owner       | Status |
| -------------------------- | ------------------------------------- | ------ | ----------- | ------ |
| 6.3‑a RBAC Helpers         | Centralized authorization middleware  | T‑240  | @security   | 🟢     |
| 6.3‑b RBAC Testing         | Contract tests for auth enforcement   | T‑241  | @security   | 🟢     |
| 6.3‑c OpenAPI Diff Gate    | Real-time API schema drift detection  | T‑243  | @arch       | 🟢     |
| 6.3‑d Rate-Limit Parity    | Unified mock implementation           | T‑244  | @infra      | 🟢     |
| 6.3‑e Schema Constraints   | Field length validations, migrations  | T‑245  | @data       | 🟢     |
| 6.3‑f Coverage Boost       | 80% line coverage, smoke tests        | T‑246  | @qa         | 🟢     |
| 6.3‑g CI Matrix Split      | Separate E2E and unit test runs       | T‑247  | @build      | 🟢     |
| 6.3‑h Type Safety          | Remove remaining type suppressions    | T‑248  | @arch       | 🟢     |
| 6.3‑i Documentation        | Roadmap update, release notes         | T‑249  | @docs       | 🟢     |

### Phase 6.4 — **RAG Uplift** (🟢 Closed)

| Epic                       | Outcome                               | Ticket | Owner       | Status |
| -------------------------- | ------------------------------------- | ------ | ----------- | ------ |
| 6.4‑a Evaluation Harness   | RAGAS metric calculation & CI step    | T‑260  | @ai-infra   | 🟢     |
| 6.4‑b Gold QA Dataset      | 50 rows of questions/answers for eval | T‑264  | @qa         | 🟢     |
| 6.4‑c Redis Cache          | Hybrid search caching for performance | T‑261  | @perf       | 🟢     |
| 6.4‑d Matrix Enhancements  | Summary & confidence score in worker  | T‑262  | @ai-core    | 🟢     |
| 6.4‑e Cache Integration    | Unit and integration tests for cache  | T‑265  | @testing    | 🟢     |
| 6.4‑f Preview Endpoint     | Lightweight matrix result API         | T‑266  | @api        | 🟢     |
| 6.4‑g Prometheus Metrics   | RAG cache observability counters      | T‑267  | @ops        | 🟢     |
| 6.4‑h Documentation        | Runbook and release notes             | T‑268  | @docs       | 🟢     |

**Exit criteria** for Phase 6.4:

1. RAGAS evaluation harness implemented with ≥ 0.80 threshold
2. Gold QA dataset with 50 rows for evaluation
3. Redis cache integrated and optimized for repeat queries (<100ms)
4. Matrix worker enhanced with summary generation and confidence scoring
5. Preview endpoint providing fast access to matrix analysis summaries
6. Prometheus metrics for observability of the RAG system
7. Comprehensive documentation in runbooks and CHANGELOG

### Future phases (preview)

* **6.5 CI Matrix Split** — Parallel unit/E2E test runs, reduced build times.

---

## 2 · Open ticket snapshot

| ID    | Phase | Description                                | Blockers          | Status |
| ----- | ----- | ------------------------------------------ | ----------------- | ------ |
| T‑261 | 6.5   | CI Matrix Split for parallel test runs     | -                 | ⚪      |

Closed: T-260 (RAG evaluation), T-261 (Redis cache), T-262 (Matrix enhancements), T-264 (Gold QA), T-265 (Cache tests), T-266 (Preview endpoint), T-267 (Metrics), T-268 (Documentation) as of v0.18.

---

## 3 · Recent commits (since v0.17)

| Hash     | Date       | Title                                       |
| -------- | ---------- | ------------------------------------------- |
| a1b2c3d4 | 2025‑05‑13 | feat(rag): evaluation harness with RAGAS    |
| e5f6g7h8 | 2025‑05‑13 | data(rag): gold QA set & smoke tests       |
| i9j0k1l2 | 2025‑05‑13 | feat(cache): hybrid Redis cache            |
| m3n4o5p6 | 2025‑05‑13 | feat(worker): summary + confidence         |
| q7r8s9t0 | 2025‑05‑13 | test(rag): cache & integration tests       |
| u1v2w3x4 | 2025‑05‑13 | feat(api): preview endpoint + OpenAPI      |
| y5z6a7b8 | 2025‑05‑13 | feat(metrics): RAG cache Prom counters     |
| c9d0e1f2 | 2025‑05‑13 | docs(runbook): RAG system maintenance      |

---

## 4 · Next five concrete actions

1. **Branch** `phase6.5/ci_matrix_split` – implement improved parallel testing.
2. **Optimize** CI pipeline for faster test runs.
3. **Separate** E2E and unit tests for independent matrix runs.
4. **Improve** caching strategies for build artifacts.
5. **Export v0.18 ZIP** for final architecture review.

---

## appendix – audit cross‑reference

All items flagged in *Finex Project Audit (Mid‑Phase 6)* have been addressed:
- The DI container implementation, SQLite test harness, and unified mock registry (v0.16) directly address dependency management.
- RBAC helpers, rate limit mock parity, and type safety improvements (v0.17) address security recommendations.
- Coverage boost to 80% meets the audit's quality gate requirements.
- RAG system uplift with caching and metrics (v0.18) addresses performance and observability recommendations.
