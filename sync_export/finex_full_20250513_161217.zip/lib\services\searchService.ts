import { Prisma } from '@prisma/client';
import { prisma } from '../db';
import { performance } from 'node:perf_hooks';
import { cacheGet, cacheSet, makeCacheKey } from './cacheService';
import { logger } from '../logger';
import { searchLatency, searchQueriesTotal } from '../metrics';

// Logger for search operations
const searchLogger = logger.child({ component: 'SearchService' });

/**
 * Performs a hybrid search using both text-based and vector-based retrieval,
 * fusing the results with Reciprocal Rank Fusion (RRF)
 *
 * Uses Redis caching to improve performance for repeated queries
 *
 * @param opts Options including the query, optional filters, and limit
 * @returns Promise resolving to an array of results with scores
 */
export async function hybridSearch(opts: {
  query: string;
  assetId?: string;
  scenarioId?: string;
  limit?: number;
}): Promise<Array<{ id: string; score: number }>> {
  const { query, assetId, scenarioId, limit = 20 } = opts;
  const startTime = performance.now();
  
  try {
    // Increment search query counter
    searchQueriesTotal.inc({ type: 'hybrid' });
    
    // Create metadata object for cache key generation
    const metadata = { assetId, scenarioId, limit };
    const cacheKey = makeCacheKey(query, metadata);
    
    // Check cache first
    const cachedResults = await cacheGet<Array<{ id: string; score: number }>>(cacheKey);
    if (cachedResults) {
      searchLogger.debug('Cache hit for search query', { query, metadata });
      
      // Record search latency including cache retrieval
      const latency = (performance.now() - startTime) / 1000;
      searchLatency.set({ type: 'hybrid_cached' }, latency);
      
      return cachedResults;
    }
    
    searchLogger.debug('Cache miss for search query', { query, metadata });
    
    // Define the RRF constant k
    const k = 60;
    
    // 1. Text-based search using tsvector
    const textResults = await textSearch(query, assetId, scenarioId, limit);
    
    // 2. Vector-based search using pgvector
    const vectorResults = await vectorSearch(query, assetId, scenarioId, limit);
    
    // 3. Fuse results with RRF
    const combined = fuseResults(textResults, vectorResults, k, limit);
    
    // Store in cache (use 5 minutes TTL)
    await cacheSet(cacheKey, combined, 300);
    
    // Record search latency for uncached search
    const latency = (performance.now() - startTime) / 1000;
    searchLatency.set({ type: 'hybrid_uncached' }, latency);
    
    return combined;
  } catch (error) {
    searchLogger.error('Search error', { 
      query, 
      assetId, 
      scenarioId, 
      error: error instanceof Error ? error.message : String(error) 
    });
    
    // Record failure latency
    const latency = (performance.now() - startTime) / 1000;
    searchLatency.set({ type: 'hybrid_error' }, latency);
    
    throw error;
  }
}

/**
 * Performs text-based search using PostgreSQL's tsvector capabilities
 */
async function textSearch(
  query: string,
  assetId?: string,
  scenarioId?: string,
  limit = 20
): Promise<Array<{ id: string; rank: number }>> {
  // Convert the query to a tsquery compatible format
  const tsQuery = query
    .replace(/[&|!():*]/g, ' ')
    .trim()
    .split(/\s+/)
    .join(' | ');
  
  if (!tsQuery) {
    return [];
  }
  
  // Build the where clause for filtering by asset or scenario
  let whereClause = '';
  const params: any[] = [tsQuery];
  
  if (assetId) {
    whereClause = 'AND t.asset_id = ?';
    params.push(assetId);
  } else if (scenarioId) {
    whereClause = 'AND t.scenario_id = ?';
    params.push(scenarioId);
  }
  
  // Execute the full-text search with ranking
  const results = await prisma.$queryRaw<Array<{ id: string; rank: number }>>(
    Prisma.sql`
      SELECT c.id, ts_rank(to_tsvector('english', c.content), to_tsquery('english', ${Prisma.sql`${tsQuery}`})) as rank
      FROM "Card" c
      JOIN "Theme" t ON c.theme_id = t.id
      WHERE to_tsvector('english', c.content) @@ to_tsquery('english', ${Prisma.sql`${tsQuery}`})
      ${Prisma.sql`${whereClause}`}
      ORDER BY rank DESC
      LIMIT ${limit}
    `
  );
  
  return results;
}

/**
 * Performs vector-based search using pgvector
 */
async function vectorSearch(
  query: string,
  assetId?: string,
  scenarioId?: string,
  limit = 20
): Promise<Array<{ id: string; similarity: number }>> {
  // For this implementation, assume we first need to generate an embedding for the query
  // This would typically involve calling an external API (OpenAI, etc.)
  // For the sake of this example, we'll simulate having the embedding
  
  // Mock embedding generation - in real implementation, call OpenAI or similar
  const queryEmbedding = await generateEmbedding(query);
  
  if (!queryEmbedding) {
    return [];
  }
  
  // Build the where clause for filtering by asset or scenario
  let whereClause = '';
  const params: any[] = [queryEmbedding];
  
  if (assetId) {
    whereClause = 'AND t.asset_id = ?';
    params.push(assetId);
  } else if (scenarioId) {
    whereClause = 'AND t.scenario_id = ?';
    params.push(scenarioId);
  }
  
  // Execute the vector search
  const results = await prisma.$queryRaw<Array<{ id: string; similarity: number }>>(
    Prisma.sql`
      SELECT ch.card_id as id, 1 - (ch.embedding <=> ${queryEmbedding}::vector) as similarity
      FROM "Chunk" ch
      JOIN "Card" c ON ch.card_id = c.id
      JOIN "Theme" t ON c.theme_id = t.id
      WHERE ch.embedding IS NOT NULL
      ${Prisma.sql`${whereClause}`}
      ORDER BY similarity DESC
      LIMIT ${limit}
    `
  );
  
  return results;
}

/**
 * Fuses search results using Reciprocal Rank Fusion (RRF)
 */
function fuseResults(
  textResults: Array<{ id: string; rank: number }>,
  vectorResults: Array<{ id: string; similarity: number }>,
  k: number,
  limit: number
): Array<{ id: string; score: number }> {
  const fusedScores = new Map<string, number>();
  
  // Process text search results
  textResults.forEach((item, i) => {
    const rrfScore = 1 / (k + i + 1);
    fusedScores.set(item.id, (fusedScores.get(item.id) || 0) + rrfScore);
  });
  
  // Process vector search results
  vectorResults.forEach((item, i) => {
    const rrfScore = 1 / (k + i + 1);
    fusedScores.set(item.id, (fusedScores.get(item.id) || 0) + rrfScore);
  });
  
  // Convert map to array and sort by score
  const results = Array.from(fusedScores.entries())
    .map(([id, score]) => ({ id, score }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
  
  return results;
}

/**
 * Generates an embedding for the given text
 * In a real implementation, this would call an external API
 */
async function generateEmbedding(text: string): Promise<number[]> {
  // Placeholder - in a real implementation, this would call OpenAI or similar
  // to generate a proper embedding vector
  return Array(1536).fill(0).map(() => Math.random() - 0.5);
}
