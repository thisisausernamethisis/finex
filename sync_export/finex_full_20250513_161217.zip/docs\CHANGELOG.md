# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Phase 7.1 - Retrieval & Prompting Overhaul (Planned)

#### Added
- Roadmap update to v0.19 with Phase 7.1 milestones (T-306)
  - Added detailed roadmap for Retrieval & Prompting Overhaul
  - Included implementation guard-rails and exit criteria

#### Coming Soon
- Domain awareness in search with domain enum field for chunks (T-301a, T-302)
- Parallel search execution for improved performance (T-305)
- Dynamic alpha parameter selection based on query content (T-303)
- Chain-of-Thought prompting with function calling (T-304)
- Re-chunking corpus to 256 ± 15% tokens with domain assignment (T-301b)

## [0.18.0] - 2025-05-13

### RAG Uplift (Phase 6.4)

#### Added
- RAG evaluation harness with RAGAS metric calculation (T-260)
  - Created evaluation framework for measuring search quality
  - Implemented CI step that exits non-zero if RAGAS score < 0.80
- Gold QA dataset with 50 financial questions and answers (T-264)
  - Created comprehensive dataset for search quality evaluation
  - Added smoke tests to verify RAGAS calculation works correctly
- Hybrid search Redis caching for improved performance (T-261)
  - Implemented Redis-based caching for search results
  - Added TTL management for cache entries with default 5-minute TTL
  - Cached search results show <100ms latency on repeat queries
- Matrix results summary and confidence score (T-262)
  - Added summary and confidence fields to matrix analysis results
  - Created Zod validators for result data with confidence range 0-1
  - Updated worker to calculate and store confidence metrics
- Matrix preview endpoint for lightweight result access (T-266)
  - Added API endpoint for accessing summaries without full results
  - Updated OpenAPI specification with new endpoint
  - Endpoint returns summary, confidence and key metadata
- RAG system Prometheus metrics (T-267)
  - Added counters for cache hits/misses
  - Added gauges for operation latency
  - Improved observability for RAG system performance

#### Documentation
- Comprehensive RAG system runbook (T-268)
  - Added maintenance procedures and configurations
  - Documented troubleshooting steps
  - Added monitoring recommendations with Prometheus queries

## [0.17.0] - 2025-05-13

### Security & Spec-Parity Sweep

#### Added
- RBAC authorization helpers for consistent access control (T-240)
  - Added `lib/authz/ensureOwner.ts` and `lib/authz/ensureTemplateOwner.ts` to centralize authorization logic
  - Simplified route handlers with reusable authorization middleware
- Contract tests for RBAC functionality (T-241)
  - Added comprehensive tests for asset and template access control
  - Ensured proper 401/403/200 response codes for different auth contexts
- OpenAPI diff gate in CI to prevent spec drift (T-243)
  - Added validators barrel file for comprehensive schema exports
  - Created script to compare runtime validators with reference spec
- Schema length constraints for better database integrity (T-245)
  - Added proper validation for text field lengths
  - Fixed potential data issues in Theme and ThemeTemplate models

#### Fixed
- Properly typed CardRepository without type suppression (T-248)
  - Removed @ts-expect-error lines with proper typing
  - Improved embedding field handling in chunks creation
- Rate limit mock parity for consistent testing (T-244)
  - Consolidated duplicate mock implementations
  - Added proper test coverage for rate limiting
  - Added migration notes for future mock consolidation

#### Changed
- Improved test coverage requirements to ≥80% (T-246)
  - Updated Vitest configuration with stricter thresholds
  - Added new matrix worker DI test for better coverage
- Enhanced ESLint configuration to prevent ts-nocheck usage (T-246)
  - Banned ts-nocheck comments to enforce type safety
  - Allowed ts-ignore and ts-expect-error with descriptions

## [Legacy]

### Removed
- Legacy helper modules (T-174)
  - Removed unused `lib/helpers/objectHelpers.ts` module with deprecated utility functions
  - Functions that were removed: `clone`, `pick`, `omit`, `merge`
  - For these operations, use lodash-es equivalents (`cloneDeep`, `pick`, `omit`, `merge`)
  - See `docs/legacy-helper-inventory.md` for full details

### Migration Guide
```typescript
// OLD: Using legacy helpers
import { clone, pick, omit, merge } from 'lib/helpers/objectHelpers';

// NEW: Using lodash-es
import { cloneDeep } from 'lodash-es/cloneDeep';
import { pick } from 'lodash-es/pick';
import { omit } from 'lodash-es/omit';
import { merge } from 'lodash-es/merge';
