import { expect, describe, it, vi, beforeEach, afterEach } from 'vitest';
import { hybridSearch } from '../../lib/services/searchService';
import * as vectorClient from '../../lib/clients';
import * as alphaScorer from '../../lib/utils/alphaScorer';
import * as cacheService from '../../lib/services/cacheService';

// Mock dependencies
vi.mock('../../lib/clients', () => ({
  similaritySearch: vi.fn(),
  getQueryEmbedding: vi.fn().mockResolvedValue(Array(1536).fill(0.1))
}));

vi.mock('../../lib/utils/alphaScorer', () => ({
  scoreMerge: vi.fn(),
  pickAlpha: vi.fn()
}));

vi.mock('../../lib/services/cacheService', () => ({
  cacheGet: vi.fn(),
  cacheSet: vi.fn(),
  makeCacheKey: vi.fn().mockImplementation((query, metadata) => `${query}:${JSON.stringify(metadata)}`)
}));

vi.mock('../../lib/db', () => ({
  prisma: {
    $queryRaw: vi.fn().mockResolvedValue([]),
    card: {
      findMany: vi.fn().mockResolvedValue([])
    }
  }
}));

vi.mock('../../lib/metrics', () => ({
  searchLatency: {
    set: vi.fn()
  },
  searchQueriesTotal: {
    inc: vi.fn()
  }
}));

describe('Domain-aware Hybrid Search', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(cacheService.cacheGet).mockResolvedValue(null); // Always cache miss for testing
    
    // Default implementation for scoreMerge (wrapped in Promise since real function is async)
    vi.mocked(alphaScorer.scoreMerge).mockImplementation((vec, kw, options) => {
      return Promise.resolve([
        { id: 'result1', score: 0.95 },
        { id: 'result2', score: 0.85 },
        { id: 'result3', score: 0.75 }
      ]);
    });
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  it('supports single domain for backward compatibility', async () => {
    // Set up mock
    vi.mocked(vectorClient.similaritySearch).mockResolvedValue([
      { id: 'card1', similarity: 0.9 }
    ]);

    // Run with single domain as array
    await hybridSearch({
      query: 'test query',
      domain: ['ASSET']
    });

    // Verify domain was passed correctly
    expect(vectorClient.similaritySearch).toHaveBeenCalledWith(
      'test query',
      20, // default limit
      ['ASSET']
    );
  });

  it('supports filtering by multiple domains', async () => {
    // Set up mock
    vi.mocked(vectorClient.similaritySearch).mockResolvedValue([
      { id: 'card1', similarity: 0.9 }
    ]);

    // Run with multiple domains
    await hybridSearch({
      query: 'test query',
      domain: ['ASSET', 'GEOGRAPHY']
    });

    // Verify domains were passed correctly
    expect(vectorClient.similaritySearch).toHaveBeenCalledWith(
      'test query',
      20, // default limit
      ['ASSET', 'GEOGRAPHY']
    );
  });

  it('passes domain correctly to scoreMerge function', async () => {
    // Set up mock
    vi.mocked(vectorClient.similaritySearch).mockResolvedValue([
      { id: 'card1', similarity: 0.9 }
    ]);

    // Import db to mock queryRaw
    const db = await import('../../lib/db');
    vi.mocked(db.prisma.$queryRaw).mockResolvedValue([
      { id: 'card2', rank: 0.85 }
    ]);

    // Run with single domain
    await hybridSearch({
      query: 'test query',
      domain: ['SUPPLY_CHAIN']
    });

    // Verify domain was passed to scoreMerge
    expect(alphaScorer.scoreMerge).toHaveBeenCalledWith(
      expect.any(Array),
      expect.any(Array),
      expect.objectContaining({
        domain: 'SUPPLY_CHAIN'
      })
    );
  });

  it('uses explicit alpha parameter when provided', async () => {
    // Set up mock
    vi.mocked(vectorClient.similaritySearch).mockResolvedValue([
      { id: 'card1', similarity: 0.9 }
    ]);

    // Import db to mock queryRaw
    const db = await import('../../lib/db');
    vi.mocked(db.prisma.$queryRaw).mockResolvedValue([
      { id: 'card2', rank: 0.85 }
    ]);

    // Run with explicit alpha
    await hybridSearch({
      query: 'test query',
      alpha: 0.75
    });

    // Verify alpha was passed to scoreMerge
    expect(alphaScorer.scoreMerge).toHaveBeenCalledWith(
      expect.any(Array),
      expect.any(Array),
      expect.objectContaining({
        alpha: 0.75
      })
    );
  });

  it('passes only first domain when single item in array for backward compatibility', async () => {
    // Set up mock
    vi.mocked(vectorClient.similaritySearch).mockResolvedValue([
      { id: 'card1', similarity: 0.9 }
    ]);

    // Import db to mock queryRaw
    const db = await import('../../lib/db');
    vi.mocked(db.prisma.$queryRaw).mockResolvedValue([
      { id: 'card2', rank: 0.85 }
    ]);

    // Run with single domain in array
    await hybridSearch({
      query: 'test query',
      domain: ['GEOGRAPHY']
    });

    // Verify only the domain string was passed to scoreMerge (not array)
    expect(alphaScorer.scoreMerge).toHaveBeenCalledWith(
      expect.any(Array),
      expect.any(Array),
      expect.objectContaining({
        domain: 'GEOGRAPHY'
      })
    );
  });

  it('does not pass single domain to scoreMerge when multiple domains present', async () => {
    // Set up mock
    vi.mocked(vectorClient.similaritySearch).mockResolvedValue([
      { id: 'card1', similarity: 0.9 }
    ]);

    // Import db to mock queryRaw
    const db = await import('../../lib/db');
    vi.mocked(db.prisma.$queryRaw).mockResolvedValue([
      { id: 'card2', rank: 0.85 }
    ]);

    // Run with multiple domains
    await hybridSearch({
      query: 'test query',
      domain: ['GEOGRAPHY', 'ASSET']
    });

    // Verify domain was NOT passed to scoreMerge when multiple domains
    expect(alphaScorer.scoreMerge).toHaveBeenCalledWith(
      expect.any(Array),
      expect.any(Array),
      expect.objectContaining({
        domain: undefined
      })
    );
  });
});
