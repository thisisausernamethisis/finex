import OpenAI from 'openai';
const openai = new OpenAI();

type Hit = { id: string; score: number };

/**
 * Interface for alpha scoring options
 */
export interface AlphaOptions {
  query?: string;            // The search query text
  domain?: string;           // Single domain (for backward compatibility)
  domains?: string[];        // Multiple domains array
  alpha?: number;            // Explicit alpha override
  useGPT?: boolean;          // Whether to use GPT for scoring (default: follows env var)
}

/**
 * Merges vector and keyword search results with dynamic alpha weighting
 * 
 * @param vec Vector search results
 * @param kw Keyword/BM25 search results
 * @param options Scoring options including domain and explicit alpha
 * @returns Promise resolving to merged results sorted by score
 */
export async function scoreMerge(
  vec: Hit[],
  kw: Hit[],
  { domain, alpha, query }: { domain?: string; alpha?: number; query?: string }
) {
  // Use explicit alpha if provided, otherwise compute dynamically
  const α = alpha !== undefined ? alpha : await pickAlpha(query, domain ? [domain] : undefined);
  const byId = new Map<string, number>();

  for (const h of vec) byId.set(h.id, (byId.get(h.id) ?? 0) + α * h.score);
  for (const h of kw)  byId.set(h.id, (byId.get(h.id) ?? 0) + (1 - α) * h.score);

  return Array.from(byId.entries())
    .map(([id, score]) => ({ id, score }))
    .sort((a, b) => b.score - a.score);
}

/**
 * Computes the optimal alpha value for balancing vector and BM25 results
 * 
 * Uses a heuristic approach or calls GPT based on configuration
 * 
 * @param query The search query (optional)
 * @param domains An array of domains to consider (optional)
 * @param options Additional options like useGPT flag
 * @returns Promise resolving to the alpha value between 0 and 1
 */
export async function pickAlpha(
  query?: string,
  domains?: string[],
  options: { useGPT?: boolean } = {}
): Promise<number> {
  const useGPT = options.useGPT ?? (process.env.FINEX_ALPHA_MODE === 'gpt');
  
  // Use GPT if explicitly requested and enabled by environment
  if (useGPT) {
    return await gptAdvisorAlpha(query, domains);
  }
  
  // Otherwise use heuristic calculation
  return calculateHeuristicAlpha(query, domains);
}

/**
 * Calculates alpha value using heuristics based on query and domain
 */
function calculateHeuristicAlpha(query?: string, domains?: string[]): number {
  // Default middle-ground alpha
  let alpha = 0.5;
  
  // Apply query-based heuristics if query is available
  if (query) {
    const queryLength = query.length;
    const hasNumbers = /\d+/.test(query);
    const hasQuotes = /["'].*["']/.test(query);
    const hasSpecialChars = /[+\-*&|!()]/.test(query);
    
    // Longer queries favor vector search (semantic understanding)
    if (queryLength > 50) alpha += 0.1;
    if (queryLength > 100) alpha += 0.05;
    
    // Queries with numbers favor keyword search (exact matching)
    if (hasNumbers) alpha -= 0.15;
    
    // Quoted phrases favor keyword search (exact phrases)
    if (hasQuotes) alpha -= 0.2;
    
    // Special search operators favor keyword search
    if (hasSpecialChars) alpha -= 0.1;
  }
  
  // Apply domain-based heuristics
  if (domains?.length) {
    // Single domain provides better context for vector search
    if (domains.length === 1) alpha += 0.1;
    
    // Multiple domains make vector search more flexible
    if (domains.length > 1) alpha += 0.05;
    
    // Specific domains may have custom weights
    if (domains.includes('ASSET')) alpha += 0.05;
    if (domains.includes('GEOGRAPHY')) alpha -= 0.05;
  }
  
  // Ensure alpha stays within valid range
  return Math.max(0.2, Math.min(0.8, alpha));
}

/**
 * Uses GPT to determine optimal alpha based on query characteristics
 */
async function gptAdvisorAlpha(query?: string, domains?: string[]): Promise<number> {
  // Skip API call if disabled or query is empty
  if (process.env.FINEX_ALPHA_MODE !== 'gpt') {
    return domains?.length ? 0.65 : 0.5;
  }

  try {
    // Construct a detailed prompt based on available information
    let prompt = 'Analyze this search query and context:';
    if (query) prompt += `\nQuery: "${query}"`;
    if (domains?.length) prompt += `\nDomains: ${domains.join(', ')}`;
    
    prompt += '\n\nReturn a single number between 0-1 representing optimal α weighting between vector (α) and keyword search (1-α)';
    prompt += '\nHigher α (closer to 1) favors vector/semantic search.';
    prompt += '\nLower α (closer to 0) favors keyword/BM25 search.';
    
    const { choices } = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      max_tokens: 4,
      temperature: 0.3,
      messages: [
        { role: 'system', content: 'You are a search algorithm tuning assistant. Analyze the query and return only a number.' },
        { role: 'user',   content: prompt },
      ],
    });
    
    const n = parseFloat(choices[0].message.content ?? '');
    return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.6;
  } catch (error) {
    console.error('Error calling GPT for alpha scoring:', error);
    return calculateHeuristicAlpha(query, domains); // Fallback to heuristic on error
  }
}
