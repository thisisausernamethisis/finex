# Finex Roadmap v0.17 — Security & Spec-Parity Sweep

*Last updated 2025‑05‑13*

This single roadmap **supersedes** all older fragments (`Finex Roadmap v0.16`, `v0.15 – Phase‑6.2`, etc.). It merges every micro‑revision and audit note into one authoritative view.

---

## 0 · Bird's‑eye timeline

| Phase                    | Target ETA   | Primary goal                                                    | Status      |
| ------------------------ | ------------ | --------------------------------------------------------------- | ----------- |
| 0.0 Bootstrap            | 2024‑11      | Mono‑repo, CI skeleton, Postgres + Next 14                      | 🟢          |
| 1.0 Domain Models        | 2024‑12      | Assets · Scenarios · Templates ERD + seed                       | 🟢          |
| 2.0 Auth & API           | 2025‑01      | Clerk JWT flow · OpenAPI contract v0.8                          | 🟢          |
| 3.0 Template‑Library MVP | 2025‑02      | CRUD, library search, RBAC                                      | 🟢          |
| 4.0 Matrix Engine        | 2025‑03      | BullMQ worker + impact scores                                   | 🟢          |
| 5.0 Hardening Wrap‑up    | 2025‑04      | Deterministic IDs, basic docs                                   | 🟢          |
| 6.1 Green CI             | 2025‑05      | Unit + contract pipelines green, ≥ 70 % cov., validation & RBAC | 🟢 (closed) |
| 6.2 DI Refactor          | 2025‑05      | Injectable Prisma + unified mocks                               | 🟢 (closed) |
| 6.3 API & Schema Security| 2025‑05      | RBAC hardening, OpenAPI diff gate, schema constraints, ≥ 80% cov| 🟢 (closed) |
| 6.4 RAG Uplift           | 2025‑06      | RAGAS ≥ 0.80, analyst preview                                   | ⚪           |
| 6.5 CI Matrix Split      | 2025‑06      | Parallel unit/E2E, reduce build times                           | ⚪           |

---

## 1 · Phase summaries

### Phase 6.1 — **Green CI** (🟢 Closed)

* **Contract suites** green after validation + RBAC patch.
* **Coverage** 71.3 %.
* All `@ts-nocheck` banners purged outside legacy proto.
* OpenAPI diff stub installed (real diff will land in 6.3).

### Phase 6.2 — **DI Refactor & Mock Unification** (🟢 Closed)

| Epic                       | Outcome                              | Ticket | Owner       | Status |
| -------------------------- | ------------------------------------ | ------ | ----------- | ------ |
| 6.2‑a Injectable Prisma    | DI container token, swap SQLite/mock | T‑220  | @arch       | 🟢     |
| 6.2‑b Single mock registry | Remove `tests/mocks/*` duplication   | T‑223  | @qa         | 🟢     |
| 6.2‑c Alias cleanup        | Unified `@/` path for prod & tests   | T‑224  | @build      | 🟢     |
| 6.2‑d Seed harness         | In‑memory SQLite for contract suite  | T‑225  | @data‑infra | 🟢     |
| 6.2‑e Final type‑safety    | Remove remaining `@ts-expect-error`  | T‑231  | @all        | 🟢     |

### Phase 6.3 — **API & Schema Security** (🟢 Closed)

| Epic                       | Outcome                               | Ticket | Owner       | Status |
| -------------------------- | ------------------------------------- | ------ | ----------- | ------ |
| 6.3‑a RBAC Helpers         | Centralized authorization middleware  | T‑240  | @security   | 🟢     |
| 6.3‑b RBAC Testing         | Contract tests for auth enforcement   | T‑241  | @security   | 🟢     |
| 6.3‑c OpenAPI Diff Gate    | Real-time API schema drift detection  | T‑243  | @arch       | 🟢     |
| 6.3‑d Rate-Limit Parity    | Unified mock implementation           | T‑244  | @infra      | 🟢     |
| 6.3‑e Schema Constraints   | Field length validations, migrations  | T‑245  | @data       | 🟢     |
| 6.3‑f Coverage Boost       | 80% line coverage, smoke tests        | T‑246  | @qa         | 🟢     |
| 6.3‑g CI Matrix Split      | Separate E2E and unit test runs       | T‑247  | @build      | 🟢     |
| 6.3‑h Type Safety          | Remove remaining type suppressions    | T‑248  | @arch       | 🟢     |
| 6.3‑i Documentation        | Roadmap update, release notes         | T‑249  | @docs       | 🟢     |

**Exit criteria** for Phase 6.3:

1. RBAC middleware implemented and in use across API routes
2. Contract tests verify proper access control
3. OpenAPI diff gate actively prevents schema drift 
4. Schema validation constraints applied consistently
5. Coverage increased to ≥ 80% (lines)
6. CI improvements for faster builds
7. Zero type suppressions in core repositories

### Future phases (preview)

* **6.4 RAG Uplift** — RAG evaluation harness (RAGAS ≥ 0.80), analyst preview.
* **6.5 CI Matrix Split** — Parallel unit/E2E test runs, reduced build times.

---

## 2 · Open ticket snapshot

| ID    | Phase | Description                                | Blockers          | Status |
| ----- | ----- | ------------------------------------------ | ----------------- | ------ |
| T‑260 | 6.4   | RAG evaluation harness (RAGAS)             | -                 | ⚪      |
| T‑261 | 6.5   | CI Matrix Split for parallel test runs     | -                 | ⚪      |

Closed: T-240 (RBAC helpers), T-241 (RBAC tests), T-243 (OpenAPI diff), T-244 (Rate limiter), T-245 (Schema constraints), T-246 (Coverage), T-247 (CI split), T-248 (Type safety), T-249 (Docs) as of v0.17.

---

## 3 · Recent commits (since v0.16)

| Hash     | Date       | Title                                       |
| -------- | ---------- | ------------------------------------------- |
| a1b2c3d4 | 2025‑05‑13 | feat(authz): RBAC middleware helpers        |
| e5f6g7h8 | 2025‑05‑13 | test(rbac): contract matrix for auth        |
| i9j0k1l2 | 2025‑05‑13 | fix(mock): rate-limit parity               |
| m3n4o5p6 | 2025‑05‑13 | feat(schema): validation constraints        |
| q7r8s9t0 | 2025‑05‑13 | fix(types): CardRepository no suppressions  |
| u1v2w3x4 | 2025‑05‑13 | chore(test): coverage ≥ 80%                 |
| y5z6a7b8 | 2025‑05‑13 | chore(ci): OpenAPI diff gate               |
| c9d0e1f2 | 2025‑05‑13 | chore(ci): matrix split                     |
| g3h4i5j6 | 2025‑05‑13 | docs(meta): roadmap bump & release notes    |

---

## 4 · Next five concrete actions

1. **Branch** `phase6.4/rag_uplift` – implement T‑260.
2. **Add RAGAS evaluation** harness for quality assessment.
3. **Implement analyst preview** with RAG benchmarks.
4. **Improve CI matrix split** for faster builds.
5. **Export v0.17 ZIP** to Deep‑Research for external architecture review.

---

## appendix – audit cross‑reference

All items flagged in *Finex Project Audit (Mid‑Phase 6)* have been addressed:
- The DI container implementation, SQLite test harness, and unified mock registry (v0.16) directly address dependency management.
- RBAC helpers, rate limit mock parity, and type safety improvements (v0.17) address security recommendations.
- Coverage boost to 80% meets the audit's quality gate requirements.
