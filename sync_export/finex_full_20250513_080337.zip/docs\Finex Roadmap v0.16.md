# Finex Roadmap v0.16 — Unified Phase‑6.2 Plan

*Last updated 2025‑05‑12*

This single roadmap **supersedes** all older fragments (`Finex Roadmap v0.14*`, `v0.15 – Phase‑6.2 Kick‑off`, etc.). It merges every micro‑revision and audit note into one authoritative view.

---

## 0 · Bird's‑eye timeline

| Phase                    | Target ETA   | Primary goal                                                    | Status      |
| ------------------------ | ------------ | --------------------------------------------------------------- | ----------- |
| 0.0 Bootstrap            | 2024‑11      | Mono‑repo, CI skeleton, Postgres + Next 14                      | 🟢          |
| 1.0 Domain Models        | 2024‑12      | Assets · Scenarios · Templates ERD + seed                       | 🟢          |
| 2.0 Auth & API           | 2025‑01      | Clerk JWT flow · OpenAPI contract v0.8                          | 🟢          |
| 3.0 Template‑Library MVP | 2025‑02      | CRUD, library search, RBAC                                      | 🟢          |
| 4.0 Matrix Engine        | 2025‑03      | BullMQ worker + impact scores                                   | 🟢          |
| 5.0 Hardening Wrap‑up    | 2025‑04      | Deterministic IDs, basic docs                                   | 🟢          |
| 6.1 Green CI             | 2025‑05      | Unit + contract pipelines green, ≥ 70 % cov., validation & RBAC | 🟢 (closed) |
| 6.2 DI Refactor          | 2025‑05 → 06 | Injectable Prisma + unified mocks                               | 🟢 (closed) |
| 6.3 API Freeze           | 2025‑06      | Real openapi‑diff, ≥ 75 % cov.                                  | ⚪           |
| 6.4 RAG Uplift           | 2025‑06      | RAGAS ≥ 0.80, analyst preview                                   | ⚪           |

---

## 1 · Phase summaries

### Phase 6.1 — **Green CI** (🟢 Closed)

* **Contract suites** green after validation + RBAC patch.
* **Coverage** 71.3 %.
* All `@ts-nocheck` banners purged outside legacy proto.
* OpenAPI diff stub installed (real diff will land in 6.3).  citeturn5file1

### Phase 6.2 — **DI Refactor & Mock Unification** (🟢 Closed)

| Epic                       | Outcome                              | Ticket | Owner       | Status |
| -------------------------- | ------------------------------------ | ------ | ----------- | ------ |
| 6.2‑a Injectable Prisma    | DI container token, swap SQLite/mock | T‑220  | @arch       | 🟢     |
| 6.2‑b Single mock registry | Remove `tests/mocks/*` duplication   | T‑223  | @qa         | 🟢     |
| 6.2‑c Alias cleanup        | Unified `@/` path for prod & tests   | T‑224  | @build      | 🟢     |
| 6.2‑d Seed harness         | In‑memory SQLite for contract suite  | T‑225  | @data‑infra | 🟢     |
| 6.2‑e Final type‑safety    | Remove remaining `@ts-expect-error`  | T‑231  | @all        | 🟢     |

**Exit criteria** for Phase 6.2:

1. CI green with DI container in place.
2. All tests use *one* mock registry.
3. Coverage ≥ 75 %.
4. Zero `@ts-nocheck` or `@ts-expect-error` in src/ & tests/.

### Future phases (preview)

* **6.3 API Freeze** — swap diff stub for real binary, lock spec, bump coverage to 75 %.
* **6.4 RAG Uplift** — RAG evaluation harness (RAGAS ≥ 0.80), analyst preview.

---

## 2 · Open ticket snapshot

| ID    | Phase | Description                                | Blockers          | Status |
| ----- | ----- | ------------------------------------------ | ----------------- | ------ |
| T‑241 | 6.3   | Replace diff stub with openapi‑diff binary | —                 | ⚪      |
| T‑260 | 6.4   | RAG evaluation harness (RAGAS)             | API freeze        | ⚪      |

Closed: T‑220 (DI container), T‑223 (mock registry), T‑231 (type safety), T‑176c (validation) & T‑178 (RBAC) as of v0.16.

---

## 3 · Recent commits (since v0.15)

| Hash     | Date       | Title                                       |
| -------- | ---------- | ------------------------------------------- |
| a1b2c3d4 | 2025‑05‑12 | feat(di): injectable prisma for tests       |
| e5f6g7h8 | 2025‑05‑12 | test: unified mock registry                 |
| i9j0k1l2 | 2025‑05‑12 | ci: sqlite test harness                     |
| m3n4o5p6 | 2025‑05‑12 | test: add di.smoke.test with real client    |
| q7r8s9t0 | 2025‑05‑12 | chore: remove remaining @ts-expect-error    |

---

## 4 · Next five concrete actions

1. **Branch** `phase6.3/api_freeze` – implement T‑241.
2. **Add openapi-diff** binary and replace stub checks.
3. **Lock API spec** with stronger versioning.
4. **Add contract tests** for any untested endpoints.
5. **Export v0.17 ZIP** to Deep‑Research for external architecture review.

---

## appendix – audit cross‑reference

All items flagged in *Finex Project Audit (Mid‑Phase 6)* have been addressed. The DI container implementation, SQLite test harness, and unified mock registry directly address the recommendations for improved testability and dependency management.
