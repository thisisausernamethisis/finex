/**
 * Unit tests for RAGAS smoke benchmark script (T-308)
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import * as fs from 'fs';
import * as path from 'path';
import * as ragas from '../../lib/utils/ragas';

// Mock fs and path modules
vi.mock('fs', () => ({
  readFileSync: vi.fn(),
}));

vi.mock('path', () => ({
  join: vi.fn(),
}));

// Mock logger
vi.mock('../../lib/logger', () => ({
  logger: {
    child: () => ({
      info: vi.fn(),
      error: vi.fn(),
      debug: vi.fn(),
    }),
  },
}));

// Mock ragas evaluate function
vi.mock('../../lib/utils/ragas', () => ({
  evaluate: vi.fn(),
}));

describe('RAGAS smoke benchmark', () => {
  // Sample test data
  const mockGoldData = [
    {
      question: 'What is the impact of rising interest rates on financial assets?',
      context: [
        'Rising interest rates typically cause bond prices to fall.',
        'Stocks may also be negatively affected as borrowing costs increase.',
      ],
      reference_answer: 'Rising interest rates generally cause bond prices to fall and can pressure stock valuations.',
      generated_answer: 'Rising interest rates cause bond prices to fall and may negatively impact stock prices due to increased borrowing costs.',
    },
    {
      question: 'How do supply chain disruptions affect manufacturing?',
      context: [
        'Supply chain disruptions lead to production delays.',
        'Manufacturing costs increase due to expedited shipping and material shortages.',
      ],
      reference_answer: 'Supply chain disruptions cause production delays and increase manufacturing costs.',
      generated_answer: 'Supply chain disruptions result in manufacturing delays and higher costs from expedited shipping and material shortages.',
    },
  ];

  beforeEach(() => {
    vi.clearAllMocks();
    
    // Mock path.join to return a fixed path
    (path.join as any).mockReturnValue('/mock/path/to/gold/smoke_20.json');
    
    // Mock fs.readFileSync to return mock gold data
    (fs.readFileSync as any).mockReturnValue(JSON.stringify(mockGoldData));
    
    // Mock ragas.evaluate to return a high score
    (ragas.evaluate as any).mockResolvedValue(0.9);
  });

  it('should pass when RAGAS score is above threshold', async () => {
    // Import the script (which immediately runs in a normal scenario)
    // Here we need to control execution for testing
    const mockExit = vi.spyOn(process, 'exit').mockImplementation(vi.fn() as any);
    
    // We're not testing the full script execution, just the key functions
    // This simulates what happens in the main() function of smoke.ts
    
    // Load gold dataset (simulating loadGoldDataset function)
    const data = fs.readFileSync('/mock/path/to/gold/smoke_20.json', 'utf8');
    const goldData = JSON.parse(data);
    
    expect(goldData).toEqual(mockGoldData);
    expect(goldData.length).toBe(2);
    
    // Compute scores (simulating computeRagasScores function)
    const scores: number[] = [];
    for (const item of goldData) {
      const score = await ragas.evaluate(item);
      scores.push(score);
    }
    
    const mean = scores.reduce((acc, val) => acc + val, 0) / scores.length;
    
    // Verify results
    expect(ragas.evaluate).toHaveBeenCalledTimes(2);
    expect(mean).toBeGreaterThan(0.82); // Above threshold
    expect(mockExit).not.toHaveBeenCalledWith(1); // Should not exit with error
  });

  it('should fail when RAGAS score is below threshold', async () => {
    // Mock ragas.evaluate to return a low score
    (ragas.evaluate as any).mockResolvedValue(0.7);
    
    const mockExit = vi.spyOn(process, 'exit').mockImplementation(vi.fn() as any);
    
    // Compute scores
    const scores: number[] = [];
    for (const item of mockGoldData) {
      const score = await ragas.evaluate(item);
      scores.push(score);
    }
    
    const mean = scores.reduce((acc, val) => acc + val, 0) / scores.length;
    
    // Verify results
    expect(mean).toBeLessThan(0.82); // Below threshold
    
    // If this was running the full script, it would exit with code 1
    if (mean < 0.82) {
      process.exit(1);
    }
    
    expect(mockExit).toHaveBeenCalledWith(1);
  });
});
