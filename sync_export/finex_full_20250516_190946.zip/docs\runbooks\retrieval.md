# Retrieval System Runbook

This document describes operational procedures for the retrieval system, including embedding generation, chunking strategies, and troubleshooting.

## Architecture

The retrieval system is based on a hybrid search approach that combines:

1. **Vector search** - Embedding-based semantic similarity
2. **Text search** - Keyword and exact phrase matching
3. **Domain filters** - Content categorization filters

## Re-chunk Operations

The system supports re-chunking operations to migrate legacy chunks to the new ChunkV2 format with improved embeddings.

### Re-chunk batch

To run a re-chunking batch operation:

```bash
# Run with dry-run to see what would happen
pnpm ts-node scripts/rechunk/start.ts --dry-run --limit 100

# Process a specific number of chunks
pnpm ts-node scripts/rechunk/start.ts --limit 500 --batch-size 100

# Process all chunks
pnpm ts-node scripts/rechunk/start.ts
```

Options:
- `--dry-run`: Preview the operation without making changes
- `--limit <number>`: Maximum number of chunks to process
- `--batch-size <number>`: Number of chunks per batch (default: 200)

The re-chunking process:
1. Fetches legacy chunks from the database
2. Generates embeddings for each chunk
3. Creates ChunkV2 records with domain classification
4. Preserves legacy chunk IDs for mapping

## Troubleshooting

### Missing or incorrect embeddings

If embeddings are missing or incorrect:

1. Check if the chunks have been processed by the rechunk worker:
   ```sql
   SELECT COUNT(*) FROM "ChunkV2" WHERE embedding IS NULL;
   ```

2. Reprocess specific chunks:
   ```bash
   pnpm ts-node scripts/rechunk/start.ts --assetId <asset-id>
   ```

3. Check the worker logs for errors:
   ```bash
   tail -f logs/worker.log | grep RECHUNK_WORKER
   ```

### Domain classification errors

To verify domain classification:

```sql
SELECT domain, COUNT(*) FROM "ChunkV2" GROUP BY domain ORDER BY COUNT(*) DESC;
```

## Performance Optimization

For optimal retrieval performance:

1. Create an IVF-FLAT index for faster vector search:
   ```sql
   CREATE INDEX chunk_v2_embedding_idx ON "ChunkV2" USING ivfflat (embedding vector_cosine_ops)
   WITH (lists = 100);
   ```

2. Run ANALYZE after major data changes:
   ```sql
   ANALYZE "ChunkV2";
   ```
