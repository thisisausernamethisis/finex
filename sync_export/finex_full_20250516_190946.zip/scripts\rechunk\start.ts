/**
 * Re-chunk runner script (T-301b)
 * 
 * This script migrates legacy Chunk data to the new ChunkV2 format
 * with embeddings. It supports batch processing with limits and dry-run mode.
 * 
 * Usage:
 *   pnpm ts-node scripts/rechunk/start.ts --limit 200 --dry-run
 *   pnpm ts-node scripts/rechunk/start.ts --batch-size 100
 */

import { PrismaClient } from '@prisma/client';
import { logger } from '../../lib/logger';
import { program } from 'commander';
import { Domain } from '../../lib/types/domain';
import { Queue } from 'bullmq';
import { QUEUES } from '../../workers/queues';

// Configure logger
const log = logger.child({ component: 'RECHUNK_RUNNER' });

// Parse command line args
program
  .option('--dry-run', 'Show what would be done without making changes')
  .option('--limit <number>', 'Limit the number of chunks to process', parseInt)
  .option('--batch-size <number>', 'Number of chunks to process in each batch', '200')
  .parse(process.argv);

const options = program.opts();
const isDryRun = options.dryRun || false;
const limit = options.limit ? parseInt(options.limit) : undefined;
const batchSize = parseInt(options.batchSize);

// Database client
const prisma = new PrismaClient();
let queue: Queue | undefined;

/**
 * Main function to run the re-chunking process
 */
async function main() {
  try {
    log.info('Starting legacy chunk migration to ChunkV2', {
      dryRun: isDryRun,
      limit: limit || 'unlimited',
      batchSize,
    });

    // Initialize queue if not dry run
    if (!isDryRun) {
      queue = new Queue(QUEUES.rechunk, {
        connection: {
          host: process.env.REDIS_HOST || 'localhost',
          port: parseInt(process.env.REDIS_PORT || '6379'),
        },
        defaultJobOptions: {
          attempts: 3,
          backoff: {
            type: 'exponential',
            delay: 1000,
          },
        },
      });
      
      log.info('Connected to rechunk queue');
    }

    // Get total count
    const totalCount = await countLegacyChunks();
    if (totalCount === 0) {
      log.info('No legacy chunks found to process');
      return;
    }

    // Process in batches
    log.info(`Found ${totalCount} legacy chunks to process`);
    const processLimit = limit || totalCount;
    let processed = 0;

    // Process in batches until we hit the limit or run out of chunks
    while (processed < processLimit) {
      const remaining = processLimit - processed;
      const batchLimit = Math.min(batchSize, remaining);
      
      // Get next batch
      const chunks = await fetchNextBatch(batchLimit, processed);
      if (chunks.length === 0) break;
      
      // Process batch
      await processBatch(chunks);
      
      processed += chunks.length;
      log.info(`Processed ${processed}/${processLimit} chunks`);
      
      // Break if we've processed all available chunks
      if (chunks.length < batchLimit) break;
    }

    log.info('Re-chunk operation completed', {
      processed,
      total: totalCount,
      dryRun: isDryRun,
    });
  } catch (error) {
    log.error('Error in re-chunk operation', {
      error: error instanceof Error ? error.message : String(error),
    });
    process.exit(1);
  } finally {
    await prisma.$disconnect();
    if (queue) await queue.close();
  }
}

/**
 * Count total legacy chunks to process
 */
async function countLegacyChunks() {
  const count = await prisma.chunk.count({
    where: {
      // Add conditions to filter chunks if needed
    },
  });
  return count;
}

/**
 * Fetch the next batch of legacy chunks to process
 */
async function fetchNextBatch(batchLimit: number, offset: number) {
  return await prisma.chunk.findMany({
    take: batchLimit,
    skip: offset,
    orderBy: {
      id: 'asc',
    },
    // Get the asset data via direct query if needed
  });
}

/**
 * Process a batch of chunks
 */
async function processBatch(chunks: any[]) {
  log.info(`Processing batch of ${chunks.length} chunks`);

  if (isDryRun) {
    // In dry-run mode, just log what would be done
    log.info('DRY RUN: Would have processed the following chunks:', {
      sample: chunks.slice(0, 3).map(c => ({
        id: c.id,
        contentPreview: c.content.substring(0, 50) + '...',
      })),
    });
    return;
  }

  // In real mode, add to queue for processing
  const jobs = chunks.map(chunk => {
    // Default domain
    const domain = Domain.OTHER;
    
    return queue!.add('rechunk', {
      chunkId: chunk.id,
      content: chunk.content,
      domain,
      assetId: chunk.assetId,
      metadata: {
        ...chunk.metadata,
        migratedAt: new Date().toISOString(),
        legacyId: chunk.id,
      },
    });
  });

  await Promise.all(jobs);
  log.info(`Added ${jobs.length} jobs to rechunk queue`);
}

/**
 * Map an asset type to a Domain enum value
 */
function mapAssetTypeToDomain(assetType?: string): Domain {
  if (!assetType) return Domain.OTHER;
  
  const typeMap: Record<string, Domain> = {
    'financial_report': Domain.FINANCE,
    'risk_assessment': Domain.REGULATORY,
    'compliance_doc': Domain.REGULATORY,
    'market_analysis': Domain.FINANCE,
    'investment_memo': Domain.FINANCE,
    'strategy_doc': Domain.ASSET,
    'technical_doc': Domain.TECHNICAL,
    'supply_chain_report': Domain.SUPPLY_CHAIN,
    'geographic_analysis': Domain.GEOGRAPHY
  };
  
  return typeMap[assetType.toLowerCase()] || Domain.OTHER;
}

// Run the script
main().catch(err => {
  log.error('Fatal error in rechunk runner', {
    error: err instanceof Error ? err.message : String(err),
  });
  process.exit(1);
});
